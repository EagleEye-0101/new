

import SwiftUI

enum JourneyPhase {
    case orientation
    case shift
    case immersive
    case integration
}

struct ExperienceJourneyWrapper: View {
    let kind: ExperienceKind
    @EnvironmentObject var store: AppStore
    @StateObject private var viewModel: ExperienceViewModel
    
    init(kind: ExperienceKind, store: AppStore) {
        self.kind = kind
        _viewModel = StateObject(wrappedValue: ExperienceViewModel(store: store))
    }
    
    var isIntro: Bool {
        if case .focused = viewModel.hubState { return true }
        return false
    }
    
    var isReflecting: Bool {
        if case .integrating = viewModel.hubState { return true }
        return false
    }
    
    var body: some View {
        ZStack {
            if !isIntro {
                ExperienceContent(kind: kind, isReflecting: isReflecting)
                    .transition(.opacity.animation(.easeInOut(duration: 1.0)))
                    .blur(radius: isReflecting ? 15 : 0)
                    .saturation(isReflecting ? 0.5 : 1.0)
            }
            
            if isIntro {
                ExperienceIntroView(kind: kind, viewModel: viewModel)
                    .transition(.opacity.combined(with: .scale(scale: 1.05)))
                    .zIndex(2)
            }
            
            if isReflecting {
                ExperienceReflectionView(kind: kind, viewModel: viewModel)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .zIndex(3)
            }
            
            VStack {
                HStack {
                    BackButton {
                        if isReflecting {
                           viewModel.finishJourney(kind)
                        } else {
                           withAnimation(.easeInOut) {
                               store.flow = .hub
                               store.hubState = .idle
                           }
                        }
                    }
                    Spacer()
                }
                Spacer()
            }
            .padding(.top, 20)
            .padding(.leading, 20)
            .zIndex(100)
        }
    }
}

struct ExperienceIntroView: View {
    let kind: ExperienceKind
    @EnvironmentObject var store: AppStore
    @ObservedObject var viewModel: ExperienceViewModel
    @State private var appear = false
    @State private var showStartButton = false
    
    var body: some View {
        ZStack {
            Color(uiColor: .systemBackground)
                .ignoresSafeArea()
            
            VStack(spacing: 32) {
                Spacer()
                
                VStack(spacing: 24) {
                    Image(systemName: kind.icon)
                        .font(.system(size: 60, weight: .thin))
                        .foregroundColor(.primary.opacity(0.8))
                        .scaleEffect(appear ? 1.0 : 0.8)
                        .opacity(appear ? 1.0 : 0)
                    
                    VStack(spacing: 16) {
                        Text(kind.rawValue)
                            .font(.title)
                            .fontWeight(.semibold)
                        
                        Text(introText)
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 40)
                            .foregroundColor(.secondary)
                    }
                    .offset(y: appear ? 0 : 20)
                    .opacity(appear ? 1.0 : 0)
                }
                
                Spacer()
                
                Button(action: {
                    viewModel.startActiveExperience(kind)
                }) {
                    HStack(spacing: 8) {
                        Text("Start Now")
                        Image(systemName: "chevron.right")
                    }
                    .font(.headline)
                    .foregroundColor(Color(uiColor: .systemBackground))
                    .padding(.horizontal, 32)
                    .padding(.vertical, 14)
                    .background(Capsule().fill(Color.primary))
                }
                .opacity(showStartButton ? 1 : 0)
                .scaleEffect(showStartButton ? 1 : 0.9)
                .padding(.bottom, 100)
            }
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.0)) {
                appear = true
            }
            
            withAnimation(.easeIn(duration: 0.5).delay(1.0)) {
                showStartButton = true
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                if viewModel.hubState == .focused(kind) {
                    viewModel.startActiveExperience(kind)
                }
            }
        }
    }
    
    private var introText: String {
        switch kind {
        case .visualStrain: return "Read the text as the environment changes."
        case .colorPerception: return "Tap the color that looks different."
        case .focusTunnel: return "Keep watching the center context."
        case .readingStability: return "Try to read the moving text."
        case .memoryLoad: return "Remember the pattern, then find it again."
        case .focusDistraction: return "Ignore the shapes. Focus on the message."
        case .cognitiveLoad: return "Clear the tasks as they appear."
        case .interactionPrecision: return "Tap the target as often as you can."
        }
    }
}

struct ExperienceReflectionView: View {
    let kind: ExperienceKind
    @EnvironmentObject var store: AppStore
    @ObservedObject var viewModel: ExperienceViewModel
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.3)
                .ignoresSafeArea()
                .onTapGesture {
                }
            
            VStack(spacing: 30) {
                Text(kind.rawValue)
                    .font(.headline)
                    .foregroundColor(.secondary)
                
                Text(reflectionText)
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, 20)
                
                Button(action: {
                    viewModel.finishJourney(kind)
                }) {
                    Text("Complete")
                        .font(.headline)
                        .foregroundColor(Color(uiColor: .systemBackground))
                        .padding(.horizontal, 40)
                        .padding(.vertical, 14)
                        .background(Capsule().fill(Color.primary))
                }
            }
            .padding(40)
            .background(.regularMaterial)
            .cornerRadius(24)
            .shadow(radius: 20)
            .padding(20)
        }
    }
    
    private var reflectionText: String {
        switch kind {
        case .visualStrain: 
            return "When the visual system's structural integrity wavers (like in severe astigmatism or exhaustion), the world separates into overlapping ghosts. The exhausting part isn't the blur—it's the constant, conscious physical effort required to continuously force those ghosts back into a single, cohesive reality."
        case .colorPerception:
            return "Color is a cognitive cheat code. When that channel degrades, the world doesn't just lose its vibrancy; it becomes an overwhelming, exhausting swarm. Without color to instantly categorize threats or targets, you are forced to rely on intense, deliberate focus on motion and shape—a focus that is easily shattered by the slightest distraction."
        case .focusTunnel:
            return "While you were optimizing the power core in the center, the safety systems in your periphery were failing. The collapse of your awareness wasn't just a visual change — it was a total loss of the context required to prevent a catastrophe."
        case .readingStability:
            return "Reading requires the eyes to anchor. When that anchor moves (like in nystagmus), comprehension drops while effort spikes."
        case .memoryLoad:
            return "Working memory is a 'leaky buffer.' By forcing active logic tasks while you tried to hold a pattern, we simulated how easily information fragments under interference. Notice how the spatial drift of the grid made even a simple 3x3 pattern feel unreliable."
        case .focusDistraction:
            return "Motion is a 'high-priority' signal for the brain. The Kinetic Tug-of-War you experienced simulates how sudden, predatory movement involuntarily hijacks focus. That physical 'tug' you felt on the central content is the bridge between your visual cortex and your survival instincts—instincts that don't care about your workspace goals."
        case .cognitiveLoad:
            return "When demands overlap and accumulate, the mind loses the quiet space needed to process them. The feeling of being overwhelmed isn't about the difficulty of a single task; it’s about the impossibility of managing them all at once."
        case .interactionPrecision:
            return "When interaction reliability changes subtly over time, routine actions begin to require conscious effort. The growing frustration comes entirely from the unpredictability of the environment, not a lack of ability."
        }
    }
}

struct ExperienceContent: View {
    let kind: ExperienceKind
    let isReflecting: Bool
    
    
    var body: some View {
        Group {
            switch kind {
            case .visualStrain: VisualStrainExperience(isReflecting: isReflecting)
            case .colorPerception: ColorPerceptionExperience(isReflecting: isReflecting)
            case .focusTunnel: FocusTunnelExperience(isReflecting: isReflecting)
            case .readingStability: ReadingStabilityExperience(isReflecting: isReflecting)
            case .memoryLoad: MemoryLoadExperience(isReflecting: isReflecting)
            case .focusDistraction: FocusDistractionExperience(isReflecting: isReflecting)
            case .cognitiveLoad: CognitiveLoadExperience(isReflecting: isReflecting)
            case .interactionPrecision: InteractionPrecisionExperience(isReflecting: isReflecting)
            }
        }
    }
}

struct VisualStrainExperience: View {
    let isReflecting: Bool
    @Environment(\.accessibilityReduceMotion) var reduceMotion
    
    @State private var timeElapsed: Double = 0
    @State private var blinkOpacity: Double = 0
    @State private var focusRigidity: Double = 0.0
    @State private var accommodationSpasm: Double = 0
    
    let timer = Timer.publish(every: 0.05, on: .main, in: .common).autoconnect()
    
    var body: some View {
        GeometryReader { geo in
            let baseStrain = isReflecting ? 0 : min(1.0, timeElapsed / 30.0)
            
            let diplopiaOffset = baseStrain * (1.0 - focusRigidity) * 40.0
            let radialBlur = baseStrain * (1.0 - focusRigidity) * 15.0
            let glareOpacity = baseStrain * (1.0 - focusRigidity) * 0.8
            
            ZStack {
                Color.black.ignoresSafeArea()
                
                RadialGradient(colors: [.white.opacity(glareOpacity), .black], center: .center, startRadius: 0, endRadius: geo.size.width)
                    .blendMode(.screen)
                    .ignoresSafeArea()
                
                ZStack {
                    FocusGeometry(time: timeElapsed, isReflecting: isReflecting)
                        .foregroundColor(.cyan)
                        .opacity(0.6 * baseStrain)
                        .offset(x: -diplopiaOffset, y: diplopiaOffset * 0.5)
                        .blendMode(.screen)
                    
                    FocusGeometry(time: timeElapsed, isReflecting: isReflecting)
                        .foregroundColor(.red)
                        .opacity(0.6 * baseStrain)
                        .offset(x: diplopiaOffset, y: -diplopiaOffset * 0.5)
                        .blendMode(.screen)
                    
                    FocusGeometry(time: timeElapsed, isReflecting: isReflecting)
                        .foregroundColor(.white.opacity(1.0 - (0.4 * baseStrain)))
                        .blur(radius: radialBlur + accommodationSpasm)
                }
                .rotationEffect(.degrees(isReflecting ? 0 : sin(timeElapsed * 0.2) * 5.0 * baseStrain))
                .scaleEffect(1.0 + (sin(timeElapsed * 1.5) * 0.02 * baseStrain))
                
                RadialGradient(
                    stops: [
                        .init(color: .clear, location: 0.2 + (0.5 * (1.0 - baseStrain))),
                        .init(color: .black.opacity(0.95 * baseStrain), location: 1.0)
                    ],
                    center: .center,
                    startRadius: 0,
                    endRadius: geo.size.width * 0.8
                )
                .ignoresSafeArea()
                .allowsHitTesting(false)
                
                Color.black.opacity(blinkOpacity)
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
                
                if !isReflecting {
                    VStack {
                        Spacer()
                        
                        Text("FORCE ALIGNMENT")
                            .font(.system(size: 14, weight: .bold, design: .monospaced))
                            .foregroundColor(.white.opacity(0.7))
                            .kerning(2.0)
                            .blur(radius: radialBlur * 0.3)
                        
                        GeometryReader { sliderGeo in
                            ZStack(alignment: .leading) {
                                Capsule()
                                    .fill(Color.white.opacity(0.1))
                                    .frame(height: 12)
                                
                                Capsule()
                                    .fill(Color.white.opacity(0.5 + (0.5 * focusRigidity)))
                                    .frame(width: max(24, sliderGeo.size.width * focusRigidity), height: 12)
                                
                                Circle()
                                    .fill(Color.white)
                                    .shadow(color: .white.opacity(0.5), radius: 10 * focusRigidity)
                                    .frame(width: 32, height: 32)
                                    .offset(x: (sliderGeo.size.width - 32) * focusRigidity)
                                    .gesture(
                                        DragGesture()
                                            .onChanged { value in
                                                let p = value.location.x / sliderGeo.size.width
                                                focusRigidity = min(1.0, max(0.0, p))
                                            }
                                    )
                            }
                        }
                        .frame(height: 32)
                        .padding(.horizontal, 40)
                        .padding(.bottom, 120)
                        .opacity(baseStrain > 0.1 ? 1.0 : 0.0)
                        .animation(.easeIn(duration: 2.0), value: baseStrain > 0.1)
                    }
                }
            }
            .onReceive(timer) { _ in
                guard !isReflecting else { return }
                timeElapsed += 0.05
                
                if focusRigidity > 0 {
                    let slipRate = 0.01 + (focusRigidity * 0.02 * baseStrain)
                    withAnimation(.linear(duration: 0.05)) {
                        focusRigidity = max(0.0, focusRigidity - slipRate)
                    }
                }
                
                if Double.random(in: 0...100) < (baseStrain * 2.0) {
                    withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.1)) {
                        accommodationSpasm = Double.random(in: 5.0...15.0) * baseStrain * (1.0 - focusRigidity)
                        if focusRigidity > 0.2 { focusRigidity -= 0.15 }
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + Double.random(in: 0.2...0.8)) {
                        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.4)) {
                            accommodationSpasm = 0
                        }
                    }
                }
                
                if Int(timeElapsed * 20) % 180 == 0 || (baseStrain > 0.8 && Int.random(in: 0...60) == 0) {
                    withAnimation(reduceMotion ? nil : .easeOut(duration: 0.05)) { blinkOpacity = 1.0 }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        withAnimation(reduceMotion ? nil : .easeIn(duration: 0.3)) { blinkOpacity = 0 }
                    }
                }
            }
        }
    }
}

private struct FocusGeometry: View {
    let time: Double
    let isReflecting: Bool
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(lineWidth: 2)
                .frame(width: 40, height: 40)
            
            Circle()
                .frame(width: 8, height: 8)
            
            ForEach(0..<4) { i in
                let size: CGFloat = 100 + CGFloat(i * 60)
                let dashPhase = isReflecting ? 0 : CGFloat(time * Double(20 + i * 10))
                
                Circle()
                    .stroke(style: StrokeStyle(lineWidth: 1.5, dash: [CGFloat(10 + i * 15), CGFloat(5 + i * 5)], dashPhase: dashPhase))
                    .frame(width: size, height: size)
                    .rotationEffect(.degrees(isReflecting ? 0 : time * (i % 2 == 0 ? 15 : -10)))
                    .opacity(0.8 - (Double(i) * 0.15))
            }
            
            Path { path in
                path.move(to: CGPoint(x: -160, y: 0))
                path.addLine(to: CGPoint(x: -30, y: 0))
                
                path.move(to: CGPoint(x: 30, y: 0))
                path.addLine(to: CGPoint(x: 160, y: 0))
                
                path.move(to: CGPoint(x: 0, y: -160))
                path.addLine(to: CGPoint(x: 0, y: -30))
                
                path.move(to: CGPoint(x: 0, y: 30))
                path.addLine(to: CGPoint(x: 0, y: 160))
            }
            .stroke(style: StrokeStyle(lineWidth: 1, dash: [4, 4]))
            .opacity(0.5)
        }
    }
}

struct ColorPerceptionExperience: View {
    let isReflecting: Bool
    @Environment(\.accessibilityReduceMotion) var reduceMotion
    
    @State private var timeElapsed: Double = 0
    @State private var entities: [ChromaticEntity] = []
    @State private var score: Int = 0
    @State private var activeTouches: Int = 0
    
    let timer = Timer.publish(every: 0.05, on: .main, in: .common).autoconnect()
    
    let distractorBaseHue: Double = 0.65
    let targetStartHue: Double = 0.0
    
    struct ChromaticEntity: Identifiable {
        let id = UUID()
        var position: CGPoint
        var velocity: CGSize
        var baseHue: Double
        var isTarget: Bool
        var scale: CGFloat
        var rotationSpeed: Double
        var currentRotation: Double
        var wobblePhase: Double
        var burstTimer: Double = 0
    }
    
    var body: some View {
        GeometryReader { geo in
            let decayProgress = isReflecting ? 0.0 : min(1.0, timeElapsed / 35.0)
            
            let globalSaturation = max(0.0, 0.8 - (decayProgress * 0.9))
            
            let globalBrightnessVariance = max(0.0, 0.5 * (1.0 - (decayProgress * 1.5)))
            
            ZStack {
                Color(white: 0.03 + (decayProgress * 0.15)).ignoresSafeArea()
                
                ForEach(entities) { entity in
                    
                    let muddyBaseline = 0.12
                    let displayedHue = isReflecting ? entity.baseHue : entity.baseHue + ((muddyBaseline - entity.baseHue) * decayProgress)
                    
                    let wobble = sin(timeElapsed * 5.0 + entity.wobblePhase) * 0.15 * entity.scale
                    
                    OrganicShape(phase: timeElapsed * entity.rotationSpeed)
                        .fill(Color(
                            hue: fract(displayedHue),
                            saturation: globalSaturation,
                            brightness: 0.5 + (entity.isTarget ? globalBrightnessVariance : -globalBrightnessVariance * 0.5)
                        ))
                        .frame(width: 50 * entity.scale + wobble, height: 50 * entity.scale)
                        .rotationEffect(.degrees(entity.currentRotation))
                        .position(entity.position)
                        .onTapGesture {
                            if !isReflecting && entity.isTarget {
                                handleTap(on: entity, in: geo.size)
                            } else if !isReflecting {
                                withAnimation { score = max(0, score - 3) }
                            }
                        }
                        .blur(radius: decayProgress * 3.0)
                }
                
                VStack {
                    if !isReflecting {
                        HStack {
                            Spacer()
                            VStack(alignment: .trailing) {
                                Text("TRACK THE RED ORGANISMS")
                                    .font(.system(size: 14, weight: .bold, design: .monospaced))
                                    .foregroundColor(.white.opacity(max(0.2, 0.8 - decayProgress)))
                                
                                Text("Identified: \(score)")
                                    .font(.system(size: 16, weight: .heavy, design: .monospaced))
                                    .foregroundColor(.white.opacity(0.8))
                            }
                        }
                        .padding(30)
                    }
                    Spacer()
                }
                
                if decayProgress > 0.3 && !isReflecting {
                    Color(hue: 0.12, saturation: 0.4, brightness: 0.5)
                        .opacity((decayProgress - 0.3) * 1.2)
                        .blendMode(.color)
                        .ignoresSafeArea()
                        .allowsHitTesting(false)
                }
            }
            .onAppear {
                spawnInitialEntities(in: geo.size)
            }
            .onReceive(timer) { _ in
                guard !isReflecting else { return }
                timeElapsed += 0.05
                updateEntities(in: geo.size)
            }
        }
    }
    
    
    private func spawnInitialEntities(in size: CGSize) {
        let total = 45 
        let targetCount = 3
        var newEntities: [ChromaticEntity] = []
        
        for i in 0..<total {
            let isTarget = i < targetCount
            newEntities.append(spawnEntity(isTarget: isTarget, in: size))
        }
        entities = newEntities
    }
    
    private func spawnEntity(isTarget: Bool, in size: CGSize) -> ChromaticEntity {
        let baseHue = isTarget ? targetStartHue : distractorBaseHue + Double.random(in: -0.05...0.05)
        
        return ChromaticEntity(
            position: CGPoint(x: CGFloat.random(in: 40...(max(41, size.width - 40))),
                              y: CGFloat.random(in: 100...(max(101, size.height - 100)))),
            velocity: CGSize(width: CGFloat.random(in: -1.0...1.0), height: CGFloat.random(in: -1.0...1.0)),
            baseHue: baseHue,
            isTarget: isTarget,
            scale: isTarget ? CGFloat.random(in: 0.8...1.0) : CGFloat.random(in: 0.7...1.3),
            rotationSpeed: isTarget ? Double.random(in: 1.5...3.0) : Double.random(in: -4.0...4.0),
            currentRotation: Double.random(in: 0...360),
            wobblePhase: Double.random(in: 0...100),
            burstTimer: Double.random(in: 0...5)
        )
    }
    
    private func updateEntities(in size: CGSize) {
        for i in 0..<entities.count {
            if entities[i].isTarget {
                let shiftRate = 0.0015
                if entities[i].baseHue < distractorBaseHue {
                    entities[i].baseHue = min(distractorBaseHue, entities[i].baseHue + shiftRate)
                }
            }
            
            entities[i].burstTimer -= 0.05
            var speedMultiplier: CGFloat = 1.0
            
            if entities[i].burstTimer <= 0 {
                entities[i].velocity.width += CGFloat.random(in: -3.0...3.0)
                entities[i].velocity.height += CGFloat.random(in: -3.0...3.0)
                entities[i].burstTimer = Double.random(in: 4.0...12.0)
                speedMultiplier = 3.0
            }
            
            entities[i].position.x += entities[i].velocity.width * speedMultiplier
            entities[i].position.y += entities[i].velocity.height * speedMultiplier
            entities[i].currentRotation += entities[i].rotationSpeed * Double(speedMultiplier)
            
            if entities[i].position.x < 20 || entities[i].position.x > size.width - 20 {
                entities[i].velocity.width *= -1
                entities[i].position.x += entities[i].velocity.width
            }
            if entities[i].position.y < 80 || entities[i].position.y > size.height - 80 {
                entities[i].velocity.height *= -1
                entities[i].position.y += entities[i].velocity.height
            }
            
            if Int.random(in: 0...10) == 0 {
                entities[i].velocity.width += CGFloat.random(in: -0.3...0.3)
                entities[i].velocity.height += CGFloat.random(in: -0.3...0.3)
            }
            
            let speed = sqrt(pow(entities[i].velocity.width, 2) + pow(entities[i].velocity.height, 2))
            if speed > 1.5 {
                entities[i].velocity.width *= 0.95
                entities[i].velocity.height *= 0.95
            }
        }
    }
    
    private func handleTap(on entity: ChromaticEntity, in size: CGSize) {
        score += 1
        entities.removeAll { $0.id == entity.id }
        
        let replacement = spawnEntity(isTarget: true, in: size)
        
        var modifiedReplacement = replacement
        modifiedReplacement.baseHue = targetStartHue 
        
        var newPos = modifiedReplacement.position
        if abs(newPos.x - entity.position.x) < 150 && abs(newPos.y - entity.position.y) < 150 {
            newPos.x = size.width / 2
            newPos.y = 120
        }
        modifiedReplacement.position = newPos
        entities.append(modifiedReplacement)
    }
    
    private func fract(_ v: Double) -> Double { v - floor(v) }
}

private struct OrganicShape: Shape {
    var phase: Double
    
    var animatableData: Double {
        get { phase }
        set { phase = newValue }
    }
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let radius = min(rect.width, rect.height) / 2
        
        for i in 0..<8 {
            let angle = (Double(i) / 8.0) * 2 * .pi
            let noise = sin(angle * 3 + phase) * 0.15 + cos(angle * 2 - phase * 0.5) * 0.1
            let r = radius * (1.0 + noise)
            
            let point = CGPoint(
                x: center.x + CGFloat(cos(angle) * r),
                y: center.y + CGFloat(sin(angle) * r)
            )
            
            if i == 0 {
                path.move(to: point)
            } else {
                path.addLine(to: point)
            }
        }
        path.closeSubpath()
        return path
    }
}

struct FocusTunnelExperience: View {
    let isReflecting: Bool
    @Environment(\.accessibilityReduceMotion) var reduceMotion
    
    @State private var timeElapsed: Double = 0
    @State private var powerOutput: Double = 45.0
    @State private var coolantLevel: Double = 98.0
    @State private var coreStability: Double = 100.0
    @State private var alertsIgnored: Int = 0
    @State private var glitchOffset: CGFloat = 0
    @State private var shakeOffset: CGSize = .zero
    @State private var ghostAlerts: [GhostAlert] = []
    
    struct GhostAlert: Identifiable {
        let id = UUID()
        var pos: CGPoint
        var opacity: Double = 0
    }
    
    let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    
    var progress: Double {
        let p = (timeElapsed - 3.0) / 10.0
        return max(0, min(p, 1.0))
    }
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                VortexBackground(time: timeElapsed, progress: progress)
                
                ReactorConsoleLayer(
                    timeElapsed: timeElapsed,
                    coolantLevel: coolantLevel,
                    coreStability: coreStability,
                    isReflecting: isReflecting,
                    glitchOffset: glitchOffset
                )
                
                ForEach(ghostAlerts) { alert in
                    Text("!! PERIPHERAL BREACH !!")
                        .font(.system(size: 10, weight: .black, design: .monospaced))
                        .foregroundColor(.red)
                        .padding(8)
                        .background(Color.red.opacity(0.1))
                        .position(alert.pos)
                        .opacity(alert.opacity)
                }
                
                ReactorFocusMask(progress: progress, isReflecting: isReflecting, size: geo.size, time: timeElapsed)
                
                VStack(spacing: 12) {
                    Text("CORE OUTPUT")
                        .font(.system(.caption2, design: .monospaced))
                        .opacity(0.6)
                    
                    Text("\(String(format: "%.1f", powerOutput))% MW")
                        .font(.system(size: 32, weight: .bold, design: .monospaced))
                        .foregroundColor(.accentColor)
                    
                    Button(action: {
                        powerOutput = min(99.9, powerOutput + 1.2)
                    }) {
                        Text("OPTIMIZE OUTPUT")
                            .font(.system(size: 14, weight: .bold, design: .monospaced))
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .background(Color.accentColor.opacity(0.1))
                            .overlay(RoundedRectangle(cornerRadius: 4).stroke(Color.accentColor.opacity(0.4), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                    
                    Text("Core sync active • Normal")
                        .font(.system(size: 10, design: .monospaced))
                        .italic()
                        .opacity(0.3)
                }
                .padding(24)
                .background(Color.black.opacity(0.4))
                .cornerRadius(4)
                .position(x: geo.size.width/2, y: geo.size.height/2)
                .offset(glitchOffset != 0 ? CGSize(width: .random(in: -5...5), height: 0) : .zero)
                
                ScanlineOverlay()
            }
            .offset(shakeOffset)
            .background(Color(white: 0.02))
            .onReceive(timer) { _ in
                guard !isReflecting else { return }
                timeElapsed += 0.1
                
                if powerOutput > 20 { powerOutput -= 0.12 }
                
                if timeElapsed > 8 {
                    coolantLevel = max(0, coolantLevel - 1.5)
                }
                
                if coolantLevel < 20 {
                    coreStability = max(0, coreStability - 0.8)
                }
                
                if coreStability < 40 && Int(timeElapsed * 10) % 15 == 0 {
                    glitchOffset = CGFloat.random(in: -4...4)
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { glitchOffset = 0 }
                }
                
                if coreStability < 30 {
                    shakeOffset = CGSize(width: .random(in: -3...3), height: .random(in: -3...3))
                } else {
                    shakeOffset = .zero
                }
                
                if progress > 0.4 && Int(timeElapsed * 10) % 40 == 0 {
                    let x = Bool.random() ? CGFloat.random(in: 20...60) : geo.size.width - CGFloat.random(in: 20...60)
                    let y = Bool.random() ? CGFloat.random(in: 20...60) : geo.size.height - CGFloat.random(in: 20...60)
                    let newAlert = GhostAlert(pos: CGPoint(x: x, y: y))
                    ghostAlerts.append(newAlert)
                    
                    let id = newAlert.id
                    withAnimation(.easeIn(duration: 0.5)) {
                        if let idx = ghostAlerts.firstIndex(where: { $0.id == id }) { ghostAlerts[idx].opacity = 0.8 }
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                        withAnimation(.easeOut(duration: 1.0)) {
                            if let idx = ghostAlerts.firstIndex(where: { $0.id == id }) { ghostAlerts[idx].opacity = 0 }
                        }
                    }
                }
            }
        }
    }
}

private struct ReactorConsoleLayer: View {
    let timeElapsed: Double
    let coolantLevel: Double
    let coreStability: Double
    let isReflecting: Bool
    let glitchOffset: CGFloat
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                GridPattern()
                    .stroke(Color.primary.opacity(0.05), lineWidth: 1)
                
                VStack(alignment: .trailing, spacing: 4) {
                    Text("COOLANT SYSTEM")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                    
                    Rectangle()
                        .fill(coolantLevel < 30 ? Color.red : Color.blue.opacity(0.6))
                        .frame(width: 120, height: 8)
                        .scaleEffect(x: coolantLevel / 100.0, y: 1.0, anchor: .trailing)
                    
                    Text("\(Int(coolantLevel))% VOLUME")
                        .font(.system(size: 12, design: .monospaced))
                        .foregroundColor(coolantLevel < 30 ? .red : .primary)
                    
                    if coolantLevel < 20 {
                        Text("!! CRITICAL LOSS !!")
                            .font(.system(size: 10, weight: .black, design: .monospaced))
                            .foregroundColor(.red)
                            .opacity(sin(timeElapsed * 10) > 0 ? 1 : 0)
                    }
                }
                .position(x: geo.size.width - 80, y: 100)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("CORE STABILITY")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                    
                    Text("\(String(format: "%.1f", coreStability))%")
                        .font(.system(size: 20, weight: .light, design: .monospaced))
                        .foregroundColor(coreStability < 50 ? .red : .accentColor)
                    
                    if coreStability < 30 {
                        Text("CONTAINMENT BREACH IMMINENT")
                            .font(.system(size: 8, weight: .bold, design: .monospaced))
                            .foregroundColor(.red)
                    }
                }
                .position(x: 100, y: geo.size.height - 120)
                .offset(y: glitchOffset)
                
                VStack(alignment: .leading, spacing: 2) {
                    ForEach(0..<8) { i in
                        Text("> SYS_LOG_\(i): CHANNEL_\(Int(timeElapsed) % 4) ACTIVE")
                            .font(.system(size: 8, design: .monospaced))
                            .opacity(0.2)
                    }
                }
                .position(x: 80, y: 200)
                
                Button(action: {}) {
                    Text("EMERGENCY SHUTDOWN")
                        .font(.system(size: 12, weight: .black, design: .monospaced))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.red)
                        .cornerRadius(4)
                }
                .position(x: 120, y: 80)
            }
        }
    }
}

private struct ReactorFocusMask: View {
    let progress: Double
    let isReflecting: Bool
    let size: CGSize
    let time: Double
    
    var body: some View {
        Canvas { context, size in
            let center = CGPoint(x: size.width / 2, y: size.height / 2)
            let maxDim = max(size.width, size.height)
            
            let targetRadius = 180.0
            let baseRadius = maxDim * 1.8 - (progress * (maxDim * 1.8 - targetRadius))
            let currentRadius = isReflecting ? maxDim * 2.0 : baseRadius
            
            context.fill(Path(CGRect(origin: .zero, size: size)), with: .color(.black))
            context.blendMode = .destinationOut
            
            for i in 0..<8 {
                let jitter = sin(time * 3 + Double(i)) * (isReflecting ? 0 : 8 * progress)
                let layerRadius = currentRadius + CGFloat(i * 15)
                let scale = 1.0 + (sin(time * 2 + Double(i)) * 0.02 * progress)
                
                var path = Path()
                path.addEllipse(in: CGRect(
                    x: center.x - (layerRadius * scale)/2 + jitter,
                    y: center.y - (layerRadius * scale)/2 - jitter,
                    width: layerRadius * scale,
                    height: layerRadius * scale
                ))
                context.fill(path, with: .color(.black.opacity(1.0 - Double(i) * 0.1)))
            }
        }
        .background(
            ZStack {
                Color.black.opacity(isReflecting ? 0.6 : 0.995)
                
                RadialGradient(
                    colors: [
                        .clear,
                        .accentColor.opacity(0.1 * progress),
                        .black.opacity(0.8)
                    ],
                    center: .center,
                    startRadius: 0,
                    endRadius: max(size.width, size.height) / 1.4
                )
            }
        )
        .compositingGroup()
    }
}

private struct GridPattern: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let step: CGFloat = 40
        for x in stride(from: 0, through: rect.width, by: step) {
            path.move(to: CGPoint(x: x, y: 0))
            path.addLine(to: CGPoint(x: x, y: rect.height))
        }
        for y in stride(from: 0, through: rect.height, by: step) {
            path.move(to: CGPoint(x: 0, y: y))
            path.addLine(to: CGPoint(x: rect.width, y: y))
        }
        return path
    }
}

private struct VortexBackground: View {
    let time: Double
    let progress: Double
    
    var body: some View {
        TimelineView(.animation) { timeline in
            Canvas { context, size in
                let center = CGPoint(x: size.width/2, y: size.height/2)
                let count = 40
                
                for i in 0..<count {
                    let angle = Double(i) * (.pi * 2 / Double(count)) + (time * 0.2)
                    let radius = (sin(time * 0.5 + Double(i) * 0.1) * 50) + (size.width * 0.4)
                    let pX = center.x + radius * cos(angle)
                    let pY = center.y + radius * sin(angle)
                    
                    let finalX = pX + (center.x - pX) * (progress * 0.5)
                    let finalY = pY + (center.y - pY) * (progress * 0.5)
                    
                    context.fill(
                        Path(ellipseIn: CGRect(x: finalX, y: finalY, width: 2, height: 2)),
                        with: .color(.accentColor.opacity(0.1 + (0.2 * progress)))
                    )
                }
            }
        }
        .allowsHitTesting(false)
    }
}

private struct ScanlineOverlay: View {
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Path { path in
                    let step: CGFloat = 8
                    for x in stride(from: 0, through: geo.size.width, by: step) {
                        path.move(to: CGPoint(x: x, y: 0))
                        path.addLine(to: CGPoint(x: x, y: geo.size.height))
                    }
                }
                .stroke(Color.white.opacity(0.03), lineWidth: 1)
                
                Rectangle()
                    .fill(.ultraThinMaterial)
                    .opacity(0.02)
            }
        }
        .allowsHitTesting(false)
    }
}

struct ReadingStabilityExperience: View {
    let isReflecting: Bool
    @State private var time: Double = 0
    let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    
    private let paragraphs = [
        "The eye does not glide across the page; it moves in rapid jumps called saccades, anchored by brief moments of stillness.",
        "When this anchoring fails, words begin to drift. A line of text becomes a moving target, requiring constant recalculation.",
        "Compensating for this instability is an invisible labor. Every sentence becomes a puzzle of reconstruction and effort.",
        "Comprehension is the first casualty of tracking instability. When the focus shifts, the meaning often slips away alongside it."
    ]
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.opacity(0.02).ignoresSafeArea()
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 50) {
                        ForEach(0..<paragraphs.count, id: \.self) { i in
                            EnhancedReadingParagraph(
                                text: paragraphs[i],
                                index: i,
                                time: time,
                                isReflecting: isReflecting
                            )
                        }
                    }
                    .padding(40)
                    .padding(.top, 40)
                }
                .scrollDisabled(true)
                
                if !isReflecting {
                    VisionDisturbanceLayer(time: time, size: geo.size)
                }
            }
        }
        .onReceive(timer) { _ in
            guard !isReflecting else { return }
            time += 0.1
        }
    }
}

private struct EnhancedReadingParagraph: View {
    let text: String
    let index: Int
    let time: Double
    let isReflecting: Bool
    
    var body: some View {
        let yOffset = isReflecting ? 0 : (sin(time * 0.4 + Double(index)) > 0.96 ? CGFloat.random(in: -40...40) : 0)
        
        VStack(alignment: .leading, spacing: 12) {
            Text(text)
                .font(.system(size: 24, weight: .medium, design: .serif))
                .lineSpacing(12 + (isReflecting ? 0 : sin(time * 0.8) * 6))
                .kerning(isReflecting ? 0 : cos(time * 0.5 + Double(index)) * 2.0)
                .blur(radius: isReflecting ? 0 : max(0, sin(time * 1.2 + Double(index)) * 1.5))
                .opacity(isReflecting ? 1.0 : 0.7 + sin(time * 0.3) * 0.2)
                .offset(y: yOffset)
                .animation(.spring(response: 0.4, dampingFraction: 0.5), value: yOffset)
                .overlay(
                    Text(text)
                        .font(.system(size: 24, weight: .medium, design: .serif))
                        .lineSpacing(12 + (isReflecting ? 0 : sin(time * 0.8) * 6))
                        .kerning(isReflecting ? 0 : cos(time * 0.5 + Double(index)) * 2.0)
                        .foregroundColor(.accentColor.opacity(0.15))
                        .offset(x: isReflecting ? 0 : sin(time * 2.0) * 2)
                        .mask(Text(text).font(.system(size: 24, weight: .medium, design: .serif)))
                        .opacity(isReflecting ? 0 : 1)
                )
        }
    }
}

private struct VisionDisturbanceLayer: View {
    let time: Double
    let size: CGSize
    
    var body: some View {
        ZStack {
            ForEach(0..<2) { i in
                Circle()
                    .fill(RadialGradient(colors: [.white.opacity(0.1), .clear], center: .center, startRadius: 0, endRadius: 150))
                    .frame(width: 300, height: 300)
                    .blur(radius: 40)
                    .offset(
                        x: sin(time * 0.2 + Double(i)) * size.width/2.5,
                        y: cos(time * 0.15 + Double(i)) * size.height/3
                    )
            }
            
            Rectangle()
                .fill(LinearGradient(colors: [.clear, .blue.opacity(0.05), .clear], startPoint: .top, endPoint: .bottom))
                .frame(height: 100)
                .offset(y: CGFloat(Int(time * 100) % Int(size.height * 2)) - size.height)
                .allowsHitTesting(false)
        }
    }
}

struct MemoryLoadExperience: View {
    let isReflecting: Bool
    @State private var pattern: [Int] = (0..<9).map { _ in Int.random(in: 0...1) }
    @State private var phase: Int = 0
    @State private var userPattern: [Int] = Array(repeating: 0, count: 9)
    
    enum Feedback { case success, failure }
    @State private var feedback: Feedback? = nil
    
    @State private var currentQuestion: LogicQuestion = LogicQuestion.generate()
    @State private var questionsSolved: Int = 0
    
    @State private var time: Double = 0
    let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        VStack(spacing: 30) {
            Text(statusText)
                .font(.system(.title3, design: .monospaced))
                .foregroundColor(feedback == .failure ? .red : .accentColor)
                .frame(height: 40)
            
            ZStack {
                if phase == 1 && !isReflecting {
                    VStack(spacing: 20) {
                        Text("SOLVE TO MAINTAIN BUFFER")
                            .font(.caption)
                            .opacity(0.6)
                        
                        Text(currentQuestion.text)
                            .font(.system(size: 32, weight: .bold, design: .monospaced))
                        
                        HStack(spacing: 20) {
                            Button("YES") { checkAnswer(true) }
                            Button("NO") { checkAnswer(false) }
                        }
                        .buttonStyle(.borderedProminent)
                        
                        Text("Questions Solved: \(questionsSolved)")
                            .font(.caption2)
                            .opacity(0.4)
                    }
                    .transition(.asymmetric(insertion: .scale.combined(with: .opacity), removal: .opacity))
                } else {
                    memoryGrid
                        .blur(radius: (phase == 2 && !isReflecting) ? 1.5 : 0)
                        .overlay(recallNoiseLayer)
                        .offset(x: feedback == .failure ? sin(time * 60) * 5 : 0)
                        .scaleEffect(feedback == .success ? 1.05 : 1.0)
                }
            }
            .frame(width: 350, height: 350)
            
            if phase == 2 && !isReflecting {
                Button(action: submitPattern) {
                    Text(feedback == nil ? "SUBMIT FOR BUFFER CHECK" : (feedback == .success ? "SUCCESS" : "FAILURE"))
                        .font(.system(.subheadline, design: .monospaced))
                        .fontWeight(.bold)
                        .padding(.horizontal, 30)
                        .padding(.vertical, 12)
                        .background(feedback == nil ? Color.accentColor : (feedback == .success ? .indigo : .red))
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .disabled(feedback != nil)
                .transition(.scale.combined(with: .opacity))
            } else if isReflecting {
                HStack(spacing: 40) {
                    MiniPatternGrid(pattern: pattern, title: "ACTUAL")
                    MiniPatternGrid(pattern: userPattern, title: "YOURS")
                }
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .onReceive(timer) { _ in
            guard !isReflecting else { return }
            time += 0.1
            
            if phase == 0 && time >= 5.0 {
                withAnimation { phase = 1 }
            } else if phase == 1 && time >= 15.0 {
                withAnimation { phase = 2 }
            }
        }
    }
    
    private var memoryGrid: some View {
        LazyVGrid(columns: Array(repeating: GridItem(.fixed(80), spacing: 20), count: 3), spacing: 20) {
            ForEach(0..<9) { i in
                RoundedRectangle(cornerRadius: 12)
                    .fill(cellColor(at: i))
                    .frame(width: 80, height: 80)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(feedback == nil ? Color.primary.opacity(0.1) : (feedback == .success ? Color.indigo : Color.red).opacity(0.3), lineWidth: 1))
                    .onTapGesture {
                        if phase == 2 && !isReflecting && feedback == nil {
                            userPattern[i] = userPattern[i] == 1 ? 0 : 1
                        }
                    }
            }
        }
        .rotationEffect(.degrees(isReflecting ? 0 : sin(time * 0.5) * 3))
        .offset(x: isReflecting ? 0 : cos(time * 0.4) * 10, y: isReflecting ? 0 : sin(time * 0.6) * 10)
    }
    
    private var recallNoiseLayer: some View {
        Group {
            if phase == 2 && !isReflecting && feedback == nil {
                Canvas { context, size in
                    for _ in 0..<500 {
                        let x = CGFloat.random(in: 0...size.width)
                        let y = CGFloat.random(in: 0...size.height)
                        context.fill(Path(CGRect(x: x, y: y, width: 1, height: 1)), with: .color(.primary.opacity(0.1)))
                    }
                }
                .allowsHitTesting(false)
            }
        }
    }
    
    private var statusText: String {
        if isReflecting { return "COMPARISON" }
        if feedback == .success { return "BUFFER RECOVERED" }
        if feedback == .failure { return "BUFFER CORRUPTED" }
        
        switch phase {
        case 0: return "IMPRINTING BUFFER..."
        case 1: return "INTERFERENCE DETECTED"
        case 2: return "RECALL FRAGMENTED"
        default: return ""
        }
    }
    
    private func cellColor(at i: Int) -> Color {
        if phase == 0 {
            return pattern[i] == 1 ? .accentColor : Color.gray.opacity(0.1)
        } else if phase == 2 {
            return userPattern[i] == 1 ? (feedback == .failure ? .red : .accentColor) : Color.gray.opacity(0.1)
        }
        return Color.gray.opacity(0.05)
    }
    
    private func checkAnswer(_ answer: Bool) {
        if answer == currentQuestion.answer {
            questionsSolved += 1
        }
        withAnimation(.spring()) {
            currentQuestion = LogicQuestion.generate()
        }
    }
    
    private func submitPattern() {
        if userPattern == pattern {
            withAnimation(.spring()) { feedback = .success }
        } else {
            withAnimation(.spring()) { feedback = .failure }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
            withAnimation {
                pattern = (0..<9).map { _ in Int.random(in: 0...1) }
                userPattern = Array(repeating: 0, count: 9)
                phase = 0
                time = 0
                feedback = nil
            }
        }
    }
}

private struct LogicQuestion {
    let text: String
    let answer: Bool
    
    static func generate() -> LogicQuestion {
        let ops = ["+", "-", ">", "<"]
        let op = ops.randomElement()!
        let a = Int.random(in: 1...20)
        let b = Int.random(in: 1...20)
        
        switch op {
        case "+":
            let sum = a + b
            let visibleSum = Bool.random() ? sum : sum + Int.random(in: -2...2)
            return LogicQuestion(text: "\(a) + \(b) = \(visibleSum)?", answer: sum == visibleSum)
        case ">":
            return LogicQuestion(text: "\(a) > \(b)?", answer: a > b)
        case "<":
            return LogicQuestion(text: "\(a) < \(b)?", answer: a < b)
        default:
            let diff = a - b
            let visibleDiff = Bool.random() ? diff : diff + Int.random(in: -2...2)
            return LogicQuestion(text: "\(a) - \(b) = \(visibleDiff)?", answer: diff == visibleDiff)
        }
    }
}

private struct MiniPatternGrid: View {
    let pattern: [Int]
    let title: String
    
    var body: some View {
        VStack(spacing: 12) {
            Text(title)
                .font(.system(size: 10, weight: .bold, design: .monospaced))
                .opacity(0.6)
            
            LazyVGrid(columns: Array(repeating: GridItem(.fixed(20), spacing: 4), count: 3), spacing: 4) {
                ForEach(0..<9) { i in
                    Rectangle()
                        .fill(pattern[i] == 1 ? Color.accentColor : Color.gray.opacity(0.2))
                        .frame(width: 20, height: 20)
                        .cornerRadius(2)
                }
            }
        }
    }
}

struct FocusDistractionExperience: View {
    let isReflecting: Bool
    
    @State private var timeDelta: Double = 0
    @State private var distractorData: [SurgicalDistractorState] = [
        SurgicalDistractorState(id: 0, label: "URGENT: 1 New Message", freqX: 0.15, freqY: 0.22),
        SurgicalDistractorState(id: 1, label: "Alert: Battery Low (10%)", freqX: 0.25, freqY: 0.12),
        SurgicalDistractorState(id: 2, label: "DANGER: Signal Lost", freqX: 0.08, freqY: 0.31)
    ]
    
    @State private var anchorDrift: CGSize = .zero
    @State private var stability: Double = 1.0
    
    let timer = Timer.publish(every: 0.05, on: .main, in: .common).autoconnect()
    
    struct SurgicalDistractorState: Identifiable {
        let id: Int
        let label: String
        let freqX: Double
        let freqY: Double
        var position: CGPoint = .zero
        var phase: Double = Double.random(in: 0...Double.pi * 2)
    }
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.opacity(0.8).ignoresSafeArea()
                
                ForEach(distractorData) { state in
                    SurgicalDistractorView(
                        isReflecting: isReflecting,
                        time: timeDelta,
                        size: geo.size,
                        label: state.label,
                        freqX: state.freqX,
                        freqY: state.freqY,
                        phase: state.phase
                    )
                }
                
                FocusSurgicalCard(
                    isReflecting: isReflecting,
                    time: timeDelta,
                    anchorDrift: $anchorDrift,
                    stability: $stability,
                    center: CGPoint(x: geo.size.width/2, y: geo.size.height/2)
                )
            }
        }
        .onReceive(timer) { _ in
            guard !isReflecting else { return }
            timeDelta += 0.05
            
            withAnimation(.linear(duration: 0.05)) {
                anchorDrift.width += CGFloat(sin(timeDelta * 0.4) * 0.8)
                anchorDrift.height += CGFloat(cos(timeDelta * 0.3) * 0.8)
                
                let driftMag = sqrt(pow(anchorDrift.width, 2) + pow(anchorDrift.height, 2))
                stability = max(0.5, 1.0 - (driftMag / 150))
            }
        }
    }
}

private struct FocusSurgicalCard: View {
    let isReflecting: Bool
    let time: Double
    @Binding var anchorDrift: CGSize
    @Binding var stability: Double
    let center: CGPoint
    
    @State private var isCorrecting = false
    
    var body: some View {
        VStack(spacing: 20) {
            if !isReflecting {
                HStack(spacing: 8) {
                    Text("COGNITIVE STABILITY")
                        .font(.system(size: 8, weight: .bold, design: .monospaced))
                        .opacity(0.5)
                    
                    ZStack(alignment: .leading) {
                        Rectangle().fill(Color.white.opacity(0.1)).frame(width: 100, height: 4)
                        Rectangle().fill(stability < 0.7 ? Color.red : Color.accentColor)
                            .frame(width: CGFloat(stability * 100), height: 4)
                    }
                }
            }
            
            ZStack {
                Circle()
                    .stroke(Color.white.opacity(0.1), lineWidth: 1)
                    .frame(width: 40, height: 40)
                    .offset(anchorDrift)
                
                Circle()
                    .fill(stability < 0.7 ? Color.red.opacity(0.8) : Color.accentColor.opacity(0.8))
                    .frame(width: 12, height: 12)
                    .offset(anchorDrift)
                    .shadow(color: stability < 0.7 ? .red : .accentColor, radius: 10)
                
                VStack(spacing: 16) {
                    Text("Involuntary attention capture arises when high-priority social signals (like notifications) compete for the same neural resources as your focal task.")
                        .font(.system(size: 16, weight: .medium, design: .serif))
                    
                    Text("Keep the anchor centered by tapping the card while reading.")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .foregroundColor(.accentColor)
                        .opacity(sin(time * 5) > 0 ? 1 : 0.5)
                }
                .multilineTextAlignment(.center)
                .padding(32)
                .background(.ultraThinMaterial)
                .cornerRadius(24)
                .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.1), lineWidth: 0.5))
                .blur(radius: (1.0 - stability) * 10)
                .scaleEffect(0.95 + (stability * 0.05))
            }
            .onTapGesture {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) {
                    anchorDrift = .zero
                    isCorrecting = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    isCorrecting = false
                }
            }
        }
        .frame(width: 320)
        .position(x: center.x, y: center.y)
    }
}

private struct SurgicalDistractorView: View {
    let isReflecting: Bool
    let time: Double
    let size: CGSize
    let label: String
    let freqX: Double
    let freqY: Double
    let phase: Double
    
    var body: some View {
        let x = size.width/2 + CGFloat(sin(time * freqX * 8 + phase)) * (size.width/2.5)
        let y = size.height/2 + CGFloat(cos(time * freqY * 8 + phase)) * (size.height/2.5)
        
        HStack(spacing: 12) {
            RoundedRectangle(cornerRadius: 6)
                .fill(Color.red)
                .frame(width: 24, height: 24)
                .overlay(Image(systemName: "bell.fill").font(.system(size: 12)).foregroundColor(.white))
            
            VStack(alignment: .leading, spacing: 1) {
                Text("MESSAGE")
                    .font(.system(size: 8, weight: .black))
                    .foregroundColor(.secondary)
                Text(label)
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundColor(.primary)
            }
            
            Spacer()
            
            Text("now")
                .font(.system(size: 8))
                .foregroundColor(.secondary)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .frame(width: 180)
        .background(.regularMaterial)
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.4), radius: 10, x: 0, y: 5)
        .position(x: x, y: y)
        .opacity(isReflecting ? 0 : 1)
        .blur(radius: isReflecting ? 20 : 0)
    }
}

struct CognitiveLoadExperience: View {
    let isReflecting: Bool
    
    @State private var tasks: [CognitiveTask] = []
    @State private var taskCounter: Int = 0
    @State private var timeElapsed: Double = 0
    @State private var lastSpawnTime: Double = 0
    
    let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    
    struct CognitiveTask: Identifiable, Equatable {
        let id: Int
        let type: TaskType
        var isCompleting: Bool = false
        let xOffset: CGFloat
        let yOffset: CGFloat
        let rotation: Double
        
        enum TaskType: Equatable {
            case multiTap(text: String, required: Int, color: Color)
            case slider(text: String, target: Double, color: Color)
            case stroop(prompt: String, validWord: String, options: [StroopOption])
            case logicToggle(text: String, requiredState: Bool, color: Color)
        }
        
        struct StroopOption: Equatable, Hashable {
            let word: String
            let colorIndex: Int
        }
    }
    
    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .trailing) {
                Color.white.opacity(0.02).ignoresSafeArea()
                
                ZStack {
                    ForEach(tasks) { task in
                        CognitiveTaskView(task: task) {
                            completeTask(task)
                        }
                        .offset(x: task.xOffset, y: task.yOffset)
                        .rotationEffect(.degrees(task.rotation))
                        .transition(.scale(scale: 0.95).combined(with: .opacity))
                        .zIndex(Double(task.id))
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .blur(radius: isReflecting ? 15 : 0)
                
                VStack {
                    HStack {
                        Spacer()
                        Text("Task: \(tasks.count)")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .padding(.top, 24)
                            .padding(.trailing, 24)
                            .opacity(tasks.isEmpty || isReflecting ? 0 : 1)
                            .animation(.easeInOut(duration: 1.2), value: isReflecting)
                    }
                    Spacer()
                }
            }
        }
        .onReceive(timer) { _ in
            guard !isReflecting else { return }
            timeElapsed += 0.1
            
            let currentSpawnRate = max(1.2, 3.2 - (timeElapsed / 20.0))
            
            if timeElapsed - lastSpawnTime >= currentSpawnRate {
                addTask()
                lastSpawnTime = timeElapsed
                
                if timeElapsed > 6.0 && Double.random(in: 0...1) > 0.6 {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                        if !isReflecting { addTask() }
                    }
                }
            }
        }
        .onAppear {
            addTask()
        }
    }
    
    private func addTask() {
        taskCounter += 1
        
        let spreadX = min(220.0, 60.0 + (timeElapsed * 2.5))
        let spreadY = min(300.0, 80.0 + (timeElapsed * 3.0))
        
        let xOffset = CGFloat.random(in: -spreadX...spreadX)
        let yOffset = CGFloat.random(in: -spreadY...spreadY)
        let rotation = Double.random(in: -5...5)
        
        let type = generateRandomTaskType()
        
        let newTask = CognitiveTask(
            id: taskCounter,
            type: type,
            xOffset: xOffset,
            yOffset: yOffset,
            rotation: rotation
        )
        
        withAnimation(.easeInOut(duration: 1.2)) {
            tasks.append(newTask)
        }
    }
    
    private func completeTask(_ task: CognitiveTask) {
        guard let index = tasks.firstIndex(where: { $0.id == task.id }) else { return }
        
        withAnimation(.easeInOut(duration: 0.5)) {
            tasks[index].isCompleting = true
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            withAnimation(.easeInOut(duration: 1.0)) {
                tasks.removeAll(where: { $0.id == task.id })
            }
        }
    }
    
    private func generateRandomTaskType() -> CognitiveTask.TaskType {
        let colors: [Color] = [.blue, .purple, .orange, .teal, .indigo, .pink]
        let color = colors.randomElement() ?? .blue
        
        let rand = Int.random(in: 0...3)
        switch rand {
        case 0:
            let prompts = ["Confirm Data", "Reject Input", "System Check", "Verify Status"]
            let required = Int.random(in: 2...4)
            return .multiTap(text: prompts.randomElement()!, required: required, color: color)
        case 1:
            return .slider(text: "Calibrate frequency", target: Double.random(in: 0.2...0.8), color: color)
        case 2:
            let requiredState = Bool.random()
            let text = requiredState ? "Ensure process is ACTIVE" : "Ensure process is HALTED"
            return .logicToggle(text: text, requiredState: requiredState, color: color)
        default:
            let words = ["RED", "BLUE", "GREEN", "YELLOW"]
            let validWord = words.randomElement()!
            
            var options: [CognitiveTask.StroopOption] = []
            let availableWords = words.shuffled()
            let availableColorIndices = [0, 1, 2, 3].shuffled()
            
            for i in 0..<3 {
                options.append(CognitiveTask.StroopOption(word: availableWords[i], colorIndex: availableColorIndices[i]))
            }
            
            if !options.contains(where: { $0.word == validWord }) {
                options[0] = CognitiveTask.StroopOption(word: validWord, colorIndex: availableColorIndices[0])
            }
            options.shuffle()
            
            return .stroop(prompt: "Select word: \(validWord)", validWord: validWord, options: options)
        }
    }
}

struct CognitiveTaskView: View {
    let task: CognitiveLoadExperience.CognitiveTask
    let onComplete: () -> Void
    
    @State private var currentTaps: Int = 0
    @State private var sliderValue: Double = 0.0
    @State private var toggleState: Bool = false
    @State private var isError: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 8) {
                Circle()
                    .fill(taskColor)
                    .frame(width: 8, height: 8)
                
                Text(taskTitle)
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(.secondary)
                
                Spacer()
                
                if case let .multiTap(_, req, _) = task.type {
                    Text("\(currentTaps)/\(req)")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                        .animation(.none, value: currentTaps)
                }
            }
            
            Group {
                switch task.type {
                case .multiTap(let text, let required, let color):
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            currentTaps += 1
                        }
                        if currentTaps >= required {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                                onComplete()
                            }
                        }
                    }) {
                        Text(text)
                            .font(.subheadline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .background(color)
                            .cornerRadius(8)
                    }
                    
                case .slider(let text, let target, let color):
                    VStack(alignment: .leading, spacing: 6) {
                        Text("\(text) (Target: \(Int(target * 100))%)")
                            .font(.caption2)
                            .foregroundColor(.primary.opacity(0.8))
                        
                        Slider(value: Binding(
                            get: { sliderValue },
                            set: { val in
                                sliderValue = val
                                if abs(val - target) < 0.04 {
                                    onComplete()
                                }
                            }
                        ), in: 0...1)
                        .tint(color)
                    }
                    
                case .logicToggle(let text, let required, let color):
                    VStack(alignment: .leading, spacing: 8) {
                        Text(text)
                            .font(.caption2)
                            .foregroundColor(.primary.opacity(0.8))
                            .fixedSize(horizontal: false, vertical: true)
                        
                        Toggle(isOn: Binding(
                            get: { toggleState },
                            set: { val in
                                withAnimation(.easeInOut(duration: 0.4)) {
                                    toggleState = val
                                }
                                if val == required {
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                                        if toggleState == required {
                                            onComplete()
                                        }
                                    }
                                }
                            }
                        )) {
                            Text(toggleState ? "ACTIVE" : "HALTED")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .animation(.none, value: toggleState)
                        }
                        .tint(color)
                    }
                    .onAppear {
                        toggleState = !required
                    }
                    
                case .stroop(let prompt, let validWord, let options):
                    VStack(alignment: .leading, spacing: 10) {
                        Text(prompt)
                            .font(.caption2)
                            .fontWeight(.semibold)
                        
                        HStack(spacing: 8) {
                            ForEach(options, id: \.word) { option in
                                Button(action: {
                                    if option.word == validWord {
                                        onComplete()
                                    } else {
                                        showError()
                                    }
                                }) {
                                    Text(option.word)
                                        .font(.caption)
                                        .fontWeight(.bold)
                                        .padding(.horizontal, 6)
                                        .padding(.vertical, 10)
                                        .frame(maxWidth: .infinity)
                                        .background(Color.primary.opacity(0.06))
                                        .foregroundColor(getColor(from: option.colorIndex))
                                        .cornerRadius(6)
                                }
                            }
                        }
                    }
                }
            }
        }
        .padding(18)
        .frame(width: 270)
        .background(.regularMaterial)
        .cornerRadius(18)
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(isError ? Color.red.opacity(0.6) : Color.clear, lineWidth: 2)
        )
        .shadow(color: Color.black.opacity(0.08), radius: 12, y: 6)
        .opacity(task.isCompleting ? 0 : 1)
        .scaleEffect(task.isCompleting ? 0.9 : 1.0)
        .offset(x: isError ? 6 : 0)
        .animation(.spring(response: 0.3, dampingFraction: 0.2), value: isError)
    }
    
    private func showError() {
        isError = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            isError = false
        }
    }
    
    private func getColor(from index: Int) -> Color {
        switch index {
        case 0: return .red
        case 1: return .blue
        case 2: return .indigo
        case 3: return .orange
        default: return .primary
        }
    }
    
    private var taskColor: Color {
        switch task.type {
        case .multiTap(_, _, let c), .slider(_, _, let c), .logicToggle(_, _, let c):
            return c
        case .stroop:
            return .purple
        }
    }
    
    private var taskTitle: String {
        switch task.type {
        case .multiTap: return "Action Sequence"
        case .slider: return "Fine Calibration"
        case .logicToggle: return "Logical Verification"
        case .stroop: return "Semantic Conflict"
        }
    }
}

struct InteractionPrecisionExperience: View {
    let isReflecting: Bool
    
    @State private var position: CGPoint = .zero
    @State private var visualOffset: CGSize = .zero
    @State private var driftOffset: CGSize = .zero
    @State private var attempts = 0
    @State private var hits = 0
    @State private var time: Double = 0
    @State private var targetScale: CGFloat = 1.0
    @State private var tapFeedback: Color = .clear
    @State private var isGlinting = false
    @State private var showShatter = false
    @State private var isJammed = false
    
    let timer = Timer.publish(every: 0.05, on: .main, in: .common).autoconnect()
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.opacity(0.8).ignoresSafeArea()
                
                VStack {
                    HStack {
                        Spacer()
                        VStack(alignment: .trailing, spacing: 4) {
                            Text("PRECISION HITS: \(hits)")
                                .font(.system(.subheadline, design: .monospaced))
                                .foregroundColor(.accentColor)
                            Text("TOTAL ATTEMPTS: \(attempts)")
                                .font(.system(.caption, design: .monospaced))
                                .foregroundColor(.secondary)
                        }
                        .padding(24)
                        .opacity(isReflecting ? 0 : 1)
                    }
                    Spacer()
                }
                
                ZStack {
                    if showShatter {
                        Circle()
                            .stroke(Color.red.opacity(0.8), lineWidth: 2)
                            .scaleEffect(2.0)
                            .opacity(0)
                    }
                    
                    TargetCircle(scale: targetScale, glint: isGlinting, stability: hits, isJammed: isJammed)
                        .offset(visualOffset)
                        .offset(driftOffset)
                        .opacity(0.6)
                        .blur(radius: isJammed ? 4 : 2)
                    
                    Button(action: { }) {
                        Circle()
                            .fill(Color.white.opacity(0.01))
                            .frame(width: 80 * targetScale, height: 80 * targetScale)
                    }
                    .simultaneousGesture(
                        DragGesture(minimumDistance: 0)
                            .onEnded { val in
                                evaluateHit(at: val.location)
                            }
                    )
                }
                .position(position)
                
                if !isReflecting {
                    Color.white.opacity(0.01)
                        .offset(x: CGFloat(sin(time * 80) * 0.5), y: CGFloat(cos(time * 75) * 0.5))
                        .allowsHitTesting(false)
                }
            }
            .onAppear {
                position = CGPoint(x: geo.size.width / 2, y: geo.size.height / 2)
            }
            .onReceive(timer) { _ in
                guard !isReflecting else { return }
                time += 0.05
                
                withAnimation(.linear(duration: 0.05)) {
                    visualOffset = CGSize(
                        width: sin(time * 4) * 15,
                        height: cos(time * 3.5) * 15
                    )
                }
                
                withAnimation(.linear(duration: 0.05)) {
                    driftOffset.width += CGFloat(sin(time * 1.2) * 2.0)
                    driftOffset.height += CGFloat(cos(time * 1.5) * 2.0)
                }
                
                if Int(time * 20) % 2 == 0 {
                    isGlinting.toggle()
                }
                
                if Int(time * 10) % 60 == 0 && !isJammed {
                    if Double.random(in: 0...1) > 0.85 {
                        withAnimation { isJammed = true }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                            withAnimation { isJammed = false }
                        }
                    }
                }
            }
        }
        .blur(radius: isReflecting ? 15 : 0)
    }
    
    private func evaluateHit(at point: CGPoint) {
        guard !isReflecting else { return }
        attempts += 1
        
        let center = position
        let distance = sqrt(pow(point.x - center.x, 2) + pow(point.y - center.y, 2))
        let radius = 40 * targetScale
        
        if isJammed {
            withAnimation(.easeInOut(duration: 0.1)) { isJammed = false }
            return
        }
        
        if distance < radius * 0.3 {
            hits += 1
            withAnimation(.spring(response: 0.3, dampingFraction: 0.5)) {
                targetScale = max(0.4, 1.0 - CGFloat(hits) * 0.06)
                position = randomPosition()
                driftOffset = .zero
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                tapFeedback = .indigo
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    tapFeedback = .clear
                }
            }
        } else if distance < radius {
            triggerShatter()
        }
    }
    
    private func triggerShatter() {
        withAnimation { showShatter = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
            showShatter = false
            withAnimation {
                hits = max(0, hits - 1)
                targetScale = 1.0
            }
        }
    }
    
    private func randomPosition() -> CGPoint {
        CGPoint(
            x: CGFloat.random(in: 100...300), 
            y: CGFloat.random(in: 200...500)
        )
    }
}

private struct TargetCircle: View {
    let scale: CGFloat
    let glint: Bool
    let stability: Int
    let isJammed: Bool
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(isJammed ? Color.red.opacity(0.8) : Color.white.opacity(0.2), lineWidth: 1)
                .frame(width: 80 * scale, height: 80 * scale)
            
            Circle()
                .fill(
                    RadialGradient(
                        colors: [isJammed ? Color.red : Color.orange, Color.red.opacity(0.8)],
                        center: .center,
                        startRadius: 0,
                        endRadius: 20 * scale
                    )
                )
                .frame(width: 24 * scale, height: 24 * scale)
                .shadow(color: .red.opacity(glint ? 0.8 : 0.4), radius: glint ? 12 : 6)
                .scaleEffect(isJammed ? 1.2 : 1.0)
                .animation(.interpolatingSpring(stiffness: 120, damping: 10), value: isJammed)
            
            if scale < 0.9 {
                Text(String(repeating: "|", count: min(stability, 15)))
                    .font(.system(size: 8, weight: .black, design: .monospaced))
                    .foregroundColor(isJammed ? .red : .white.opacity(0.3))
                    .offset(y: 45 * scale)
            }
        }
    }
}
