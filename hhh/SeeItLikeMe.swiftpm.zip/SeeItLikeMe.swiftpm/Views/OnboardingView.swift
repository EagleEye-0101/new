

import SwiftUI

struct OnboardingView: View {
    @EnvironmentObject var store: AppStore
    @StateObject private var viewModel: OnboardingViewModel
    
    init(store: AppStore) {
        _viewModel = StateObject(wrappedValue: OnboardingViewModel(store: store))
    }
    
    @State private var currentPage = 1
    @State private var showButton = false
    @State private var textOpacity = 0.0
    
    @State private var floatOffset: CGFloat = 0.0
    
    var body: some View {
        ZStack {
            AmbientDustBackground()
            
            VStack(spacing: 0) {
                Spacer()
                
                TabView(selection: $currentPage) {
                    OnboardingPageOne(currentPage: currentPage)
                        .tag(1)
                    OnboardingPageTwo(currentPage: currentPage)
                        .tag(2)
                    OnboardingPageThree(showButton: $showButton, currentPage: currentPage)
                        .tag(3)
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
                .frame(height: 350)
                .offset(y: floatOffset)
                .onAppear {
                    withAnimation(Animation.easeInOut(duration: 4.0).repeatForever(autoreverses: true)) {
                        floatOffset = -10.0
                    }
                }
                
                Spacer()
                
                ZStack {
                    if currentPage < 3 {
                        Button(action: {
                            withAnimation(.easeInOut(duration: 0.5)) {
                                currentPage += 1
                            }
                        }) {
                            Text("Next")
                                .font(.headline)
                                .foregroundColor(.secondary)
                        }
                        .padding(.bottom, 60)
                        .opacity(textOpacity)
                        .transition(.opacity)
                    } else if showButton {
                        BeginJourneyButton(action: {
                            viewModel.completeOnboarding()
                        })
                        .padding(.bottom, 60)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
                .frame(height: 100)
            }
        }
        .onAppear {
            withAnimation(.easeIn(duration: 1.0).delay(2.5)) {
                textOpacity = 1.0
            }
        }
    }
}

struct OnboardingPageOne: View {
    let currentPage: Int
    @State private var op1 = 0.0
    @State private var op2 = 0.0
    
    var body: some View {
        VStack(spacing: 20) {
            Text("See It Like Me")
                .font(.system(size: 44, weight: .thin, design: .serif))
                .italic()
                .opacity(op1)
            
            Text("Interface design is more than pixels.\nIt is the lens through which we experience the world.")
                .font(.title3.weight(.light))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
                .opacity(op2)
        }
        .onAppear {
            if currentPage == 1 { triggerAnimations() }
        }
        .onChange(of: currentPage) { newValue in
            if newValue == 1 { triggerAnimations() }
        }
    }
    
    private func triggerAnimations() {
        withAnimation(.easeIn(duration: 1.5).delay(0.5)) { op1 = 1.0 }
        withAnimation(.easeIn(duration: 1.5).delay(1.5)) { op2 = 0.8 }
    }
}

struct OnboardingPageTwo: View {
    let currentPage: Int
    @State private var op1 = 0.0
    @State private var op2 = 0.0
    
    var body: some View {
        VStack(spacing: 24) {
            Text("Perspective")
                .font(.title.weight(.light))
                .opacity(op1)
            
            Text("These experiences may feel subtle, or even uncomfortable. There is no right or wrong way to perceive.")
                .font(.body)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 60)
                .opacity(op2)
        }
        .onAppear {
            if currentPage == 2 { triggerAnimations() }
        }
        .onChange(of: currentPage) { newValue in
            if newValue == 2 { triggerAnimations() }
        }
    }
    
    private func triggerAnimations() {
        withAnimation(.easeIn(duration: 1.5).delay(0.2)) { op1 = 1.0 }
        withAnimation(.easeIn(duration: 1.5).delay(1.2)) { op2 = 0.7 }
    }
}

struct OnboardingPageThree: View {
    @Binding var showButton: Bool
    let currentPage: Int
    @State private var op1 = 0.0
    @State private var op2 = 0.0
    @State private var hasTriggered = false
    
    var body: some View {
        VStack(spacing: 24) {
            Text("An Invitation")
                .font(.title.weight(.light))
                .opacity(op1)
            
            Text("Step into a series of living environments designed to shift your focus and challenge your interaction.")
                .font(.body)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 60)
                .opacity(op2)
        }
        .onAppear {
            if currentPage == 3 { triggerAnimations() }
        }
        .onChange(of: currentPage) { newValue in
            if newValue == 3 { triggerAnimations() }
        }
    }
    
    private func triggerAnimations() {
        guard !hasTriggered else { return }
        hasTriggered = true
        
        withAnimation(.easeIn(duration: 1.5).delay(0.2)) { op1 = 1.0 }
        withAnimation(.easeIn(duration: 1.5).delay(1.2)) { op2 = 0.7 }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            withAnimation(.easeInOut(duration: 1.0)) {
                showButton = true
            }
        }
    }
}

struct BeginJourneyButton: View {
    let action: () -> Void
    @State private var isPulsing = false
    
    var body: some View {
        Button(action: action) {
            Text("Begin the Journey")
                .font(.title3.weight(.medium))
                .padding(.horizontal, 40)
                .padding(.vertical, 18)
                .background(
                    Capsule()
                        .fill(Color.primary.opacity(isPulsing ? 0.2 : 0.05))
                        .shadow(color: Color.primary.opacity(isPulsing ? 0.3 : 0.0), radius: isPulsing ? 15 : 5, x: 0, y: 0)
                )
                .overlay(Capsule().stroke(Color.primary.opacity(0.3), lineWidth: 0.5))
                .scaleEffect(isPulsing ? 1.02 : 0.98)
        }
        .onAppear {
            withAnimation(Animation.easeInOut(duration: 2.5).repeatForever(autoreverses: true)) {
                isPulsing = true
            }
        }
    }
}

struct AmbientDustBackground: View {
    var body: some View {
        TimelineView(.animation) { timeline in
            Canvas { context, size in
                let now = timeline.date.timeIntervalSinceReferenceDate
                
                for i in 0..<35 {
                    let seed1 = Double((i * 13) % 100) / 100.0
                    let seed2 = Double((i * 17) % 100) / 100.0
                    let speed = 0.15 + (seed1 * 0.2)
                    
                    let yPos = size.height - CGFloat((now * speed * 50) .truncatingRemainder(dividingBy: Double(size.height + 100))) + 50
                    let xOffset = sin(now * 0.3 + seed2 * .pi * 2) * 50 * seed1
                    let xPos = (size.width * seed2) + CGFloat(xOffset)
                    
                    let radius = 1.0 + (seed1 * 4.0)
                    let opacity = 0.05 + (seed2 * 0.2)
                    
                    let rect = CGRect(x: xPos, y: yPos, width: radius * 2, height: radius * 2)
                    context.opacity = opacity
                    context.fill(Path(ellipseIn: rect), with: .color(.white))
                }
            }
            .blur(radius: 1.5)
        }
        .ignoresSafeArea()
    }
}