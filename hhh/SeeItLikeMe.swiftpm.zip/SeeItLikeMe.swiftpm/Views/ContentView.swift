import SwiftUI

struct ContentView: View {
    @StateObject private var store = AppStore()
    @StateObject private var audioManager = AmbientAudioPlayer.shared
    
    var body: some View {
        ZStack {
            AmbientBackground()
            
            ZStack {
                switch store.flow {
                case .onboarding:
                    OnboardingView(store: store)
                        .transition(.opacity.combined(with: .scale(scale: 1.1)))
                case .hub:
                    HubView(store: store)
                        .transition(.opacity.combined(with: .scale(scale: 0.9)))
                case .journey(let kind):
                    ExperienceJourneyWrapper(kind: kind, store: store)
                        .transition(.opacity)
                case .synthesis:
                    SynthesisView(store: store)
                        .transition(.opacity)
                }
            }
            .animation(.easeInOut(duration: 1.2), value: store.flow)

            
            if store.flow != .onboarding {
                VStack {
                    Spacer()
                    BottomDock()
                }
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .ignoresSafeArea(.keyboard)
                .animation(.spring(response: 0.8, dampingFraction: 0.8), value: store.flow)
            }
            
            if store.showMenu {
                CalmMenuOverlay()
            }
        }
        .environmentObject(store)
        .environmentObject(audioManager)
        .preferredColorScheme(.dark)
        .onAppear {
            audioManager.start()
        }
    }
}
