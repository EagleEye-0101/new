import Foundation
import AVFoundation
import UIKit

@MainActor
class AmbientAudioPlayer: ObservableObject {
    static let shared = AmbientAudioPlayer()
    
    private var player: AVAudioPlayer?
    
    @Published var isMuted: Bool = false {
        didSet {
            player?.volume = isMuted ? 0.0 : 0.8
        }
    }
    
    private init() {
        setupAudio()
    }
    
    private func setupAudio() {
        guard let url = Bundle.main.url(forResource: "ambient", withExtension: "wav") else {
            print("Failed to find ambient.wav in bundle.")
            return
        }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default, options: .mixWithOthers)
            try AVAudioSession.sharedInstance().setActive(true)
            
            player = try AVAudioPlayer(contentsOf: url)
            player?.numberOfLoops = -1
            player?.volume = 0.8
            player?.prepareToPlay()
            print("Audio Player prepared successfully.")
        } catch {
            print("Failed to initialize AVAudioPlayer: \(error)")
        }
    }
    
    func start() {
        print("Starting ambient audio...")
        player?.play()
    }
    
    func stop() {
        player?.stop()
    }
}
