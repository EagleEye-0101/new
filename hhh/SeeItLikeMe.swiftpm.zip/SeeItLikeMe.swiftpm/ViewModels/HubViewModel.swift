import SwiftUI

class HubViewModel: ObservableObject {
    private let store: AppStore
    
    init(store: AppStore) {
        self.store = store
    }
    
    var hubState: HubState { store.hubState }
    
    func beginJourney(_ kind: ExperienceKind) {
        store.beginJourney(kind)
    }
    
    func position(for kind: ExperienceKind, in size: CGSize) -> CGPoint {
        let index = CGFloat(ExperienceKind.allCases.firstIndex(of: kind) ?? 0)
        let total = CGFloat(ExperienceKind.allCases.count)
        let angle = (index / total) * 2 * .pi
        let radius = min(size.width, size.height) * 0.38
        
        return CGPoint(
            x: size.width / 2 + cos(angle) * radius,
            y: size.height / 2 + sin(angle) * radius
        )
    }
}
