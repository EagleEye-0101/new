//
//  ExperienceViews.swift
//  SeeItLikeMe
//
//  Created by student on 10/02/26.
//



//
//  JourneyPhase.swift
//  SeeItLikeMe
//
//  Created by Teacher on 10/02/2026.
//


import SwiftUI

enum JourneyPhase {
    case orientation
    case shift
    case immersive
    case integration
}

struct ExperienceJourneyWrapper: View {
    let kind: ExperienceKind
    @EnvironmentObject var store: AppStore
    @StateObject private var viewModel: ExperienceViewModel
    
    init(kind: ExperienceKind, store: AppStore) {
        self.kind = kind
        _viewModel = StateObject(wrappedValue: ExperienceViewModel(store: store))
    }
    
    // Derived state for cleaner view logic
    var isIntro: Bool {
        if case .focused = viewModel.hubState { return true }
        return false
    }
    
    var isReflecting: Bool {
        if case .integrating = viewModel.hubState { return true }
        return false
    }
    
    var body: some View {
        ZStack {
            // LAYER 1: Active Experience (Always visible once started, reduced during intro/reflection)
            if !isIntro {
                ExperienceContent(kind: kind, isReflecting: isReflecting)
                    .transition(.opacity.animation(.easeInOut(duration: 1.0)))
                    .blur(radius: isReflecting ? 15 : 0) // Blur during reflection
                    .saturation(isReflecting ? 0.5 : 1.0)
            }
            
            // LAYER 2: Intro Overlay
            if isIntro {
                ExperienceIntroView(kind: kind, viewModel: viewModel)
                    .transition(.opacity.combined(with: .scale(scale: 1.05)))
                    .zIndex(2)
            }
            
            // LAYER 3: Reflection Overlay
            if isReflecting {
                ExperienceReflectionView(kind: kind, viewModel: viewModel)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .zIndex(3)
            }
            
            // Back Button (Top Left)
            // Available in all states, exits gracefully
            VStack {
                HStack {
                    BackButton {
                        // Clean exit logic handled by Models based on current state
                        if isReflecting {
                           viewModel.finishJourney(kind)
                        } else {
                           // If active/intro, just leave
                           withAnimation(.easeInOut) {
                               store.flow = .hub
                               store.hubState = .idle
                           }
                        }
                    }
                    Spacer()
                }
                Spacer()
            }
            .padding(.top, 20)
            .padding(.leading, 20)
            .zIndex(100)
        }
    }
}

// MARK: - Intro View
struct ExperienceIntroView: View {
    let kind: ExperienceKind
    @EnvironmentObject var store: AppStore
    @ObservedObject var viewModel: ExperienceViewModel
    @State private var appear = false
    @State private var showStartButton = false
    
    var body: some View {
        ZStack {
            Color(uiColor: .systemBackground)
                .ignoresSafeArea()
            
            VStack(spacing: 32) {
                Spacer()
                
                VStack(spacing: 24) {
                    Image(systemName: kind.icon)
                        .font(.system(size: 60, weight: .thin))
                        .foregroundColor(.primary.opacity(0.8))
                        .scaleEffect(appear ? 1.0 : 0.8)
                        .opacity(appear ? 1.0 : 0)
                    
                    VStack(spacing: 16) {
                        Text(kind.rawValue)
                            .font(.title)
                            .fontWeight(.semibold)
                        
                        Text(introText)
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 40)
                            .foregroundColor(.secondary)
                    }
                    .offset(y: appear ? 0 : 20)
                    .opacity(appear ? 1.0 : 0)
                }
                
                Spacer()
                
                // Start Now Button
                Button(action: {
                    viewModel.startActiveExperience(kind)
                }) {
                    HStack(spacing: 8) {
                        Text("Start Now")
                        Image(systemName: "chevron.right")
                    }
                    .font(.headline)
                    .foregroundColor(Color(uiColor: .systemBackground))
                    .padding(.horizontal, 32)
                    .padding(.vertical, 14)
                    .background(Capsule().fill(Color.primary))
                }
                .opacity(showStartButton ? 1 : 0)
                .scaleEffect(showStartButton ? 1 : 0.9)
                .padding(.bottom, 100)
            }
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.0)) {
                appear = true
            }
            
            // Show button after 1s
            withAnimation(.easeIn(duration: 0.5).delay(1.0)) {
                showStartButton = true
            }
            
            // Auto-advance to active after 3 seconds (snappier)
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                // Ensure we don't advance if the user already clicked
                if viewModel.hubState == .focused(kind) {
                    viewModel.startActiveExperience(kind)
                }
            }
        }
    }
    
    private var introText: String {
        switch kind {
        case .visualStrain: return "Read the text as the environment changes."
        case .colorPerception: return "Tap the color that looks different."
        case .focusTunnel: return "Keep watching the center context."
        case .readingStability: return "Try to read the moving text."
        case .memoryLoad: return "Remember the pattern, then find it again."
        case .focusDistraction: return "Ignore the shapes. Focus on the message."
        case .cognitiveLoad: return "Clear the tasks as they appear."
        case .interactionPrecision: return "Tap the target as often as you can."
        }
    }
}

// MARK: - Reflection View
struct ExperienceReflectionView: View {
    let kind: ExperienceKind
    @EnvironmentObject var store: AppStore
    @ObservedObject var viewModel: ExperienceViewModel
    
    var body: some View {
        ZStack {
            // Dimmed backdrop
            Color.black.opacity(0.3)
                .ignoresSafeArea()
                .onTapGesture {
                    // Optional: Tap outside to close? 
                    // No, keeping it explicit with the button.
                }
            
            VStack(spacing: 30) {
                Text(kind.rawValue)
                    .font(.headline)
                    .foregroundColor(.secondary)
                
                Text(reflectionText)
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, 20)
                
                Button(action: {
                    viewModel.finishJourney(kind)
                }) {
                    Text("Complete")
                        .font(.headline)
                        .foregroundColor(Color(uiColor: .systemBackground))
                        .padding(.horizontal, 40)
                        .padding(.vertical, 14)
                        .background(Capsule().fill(Color.primary))
                }
            }
            .padding(40)
            .background(.regularMaterial)
            .cornerRadius(24)
            .shadow(radius: 20)
            .padding(20)
        }
    }
    
    private var reflectionText: String {
        switch kind {
        case .visualStrain: 
            return "When the environment lacks stability, your visual system compensates quietly. Tiny fluctuations in contrast, spacing, and alignment force the eyes and brain into a state of continuous adjustment. This invisible effort compounds, transforming a simple reading task into a source of quiet fatigue."
        case .colorPerception:
            return "As the shades drew closer, certainty quietly disappeared. At some point, seeing became guessing. That subtle shift — from knowing to doubting — is a constant reality for many. The difference was always there. Your confidence in finding it was not."
        case .focusTunnel:
            return "While you were optimizing the power core in the center, the safety systems in your periphery were failing. The collapse of your awareness wasn't just a visual change — it was a total loss of the context required to prevent a catastrophe."
        case .readingStability:
            return "Reading requires the eyes to anchor. When that anchor moves (like in nystagmus), comprehension drops while effort spikes."
        case .memoryLoad:
            return "Working memory is a 'leaky buffer.' By forcing active logic tasks while you tried to hold a pattern, we simulated how easily information fragments under interference. Notice how the spatial drift of the grid made even a simple 3x3 pattern feel unreliable."
        case .focusDistraction:
            return "Motion is a 'high-priority' signal for the brain. The Kinetic Tug-of-War you experienced simulates how sudden, predatory movement involuntarily hijacks focus. That physical 'tug' you felt on the central content is the bridge between your visual cortex and your survival instincts—instincts that don't care about your workspace goals."
        case .cognitiveLoad:
            return "When demands overlap and accumulate, the mind loses the quiet space needed to process them. The feeling of being overwhelmed isn't about the difficulty of a single task; it’s about the impossibility of managing them all at once."
        case .interactionPrecision:
            return "When interaction reliability changes subtly over time, routine actions begin to require conscious effort. The growing frustration comes entirely from the unpredictability of the environment, not a lack of ability."
        }
    }
}

struct ExperienceContent: View {
    let kind: ExperienceKind
    let isReflecting: Bool
    
    // We pass isReflecting so experiences can pause/slow down if they want,
    // though the wrapper already blurs them.
    
    var body: some View {
        Group {
            switch kind {
            case .visualStrain: VisualStrainExperience(isReflecting: isReflecting)
            case .colorPerception: ColorPerceptionExperience(isReflecting: isReflecting)
            case .focusTunnel: FocusTunnelExperience(isReflecting: isReflecting)
            case .readingStability: ReadingStabilityExperience(isReflecting: isReflecting)
            case .memoryLoad: MemoryLoadExperience(isReflecting: isReflecting)
            case .focusDistraction: FocusDistractionExperience(isReflecting: isReflecting)
            case .cognitiveLoad: CognitiveLoadExperience(isReflecting: isReflecting)
            case .interactionPrecision: InteractionPrecisionExperience(isReflecting: isReflecting)
            }
        }
    }
}

// --- Experience Implementations ---

struct VisualStrainExperience: View {
    let isReflecting: Bool
    
    @State private var timeElapsed: Double = 0
    @State private var blinkOpacity: Double = 0
    @State private var lastInteractionTime: Double = 0
    @State private var accommodationBlur: Double = 0
    @State private var floaters: [BiologicalFloater] = []
    
    let timer = Timer.publish(every: 0.05, on: .main, in: .common).autoconnect()
    
    struct BiologicalFloater: Identifiable {
        let id = UUID()
        var segments: [CGPoint]
        var velocity: CGSize
        var opacity: Double
    }
    
    let paragraphs = [
        "Language gives us the illusion of concrete meaning, but interpretation is inherently fluid.",
        "When the visual foundation becomes unstable, reading shifts from effortless comprehension to active decryption.",
        "Interpretation is a physical act; it requires a stable frame of reference that is currently failing.",
        "The mind attempts to fill in the gaps, but the gaps are widening beyond the reach of intuition.",
        "This effort is rarely loud; it is a quiet, accumulating toll on cognitive resources.",
        "The eyes do not just see; they actively hunt for stability in a world of constant motion.",
        "Fatigue is not a sudden wall, but a slow erosion of clarity and confidence.",
        "We take for granted the stillness of the printed word, yet that stillness is a collaborative achievement of neurology.",
        "When the signal weakens, the noise becomes the message, and the mind wanders into the blur.",
        "Accessibility is the bridge between a fragmented perception and a coherent understanding."
    ]
    
    var body: some View {
        GeometryReader { geo in
            let strain = isReflecting ? 0 : min(1.0, timeElapsed / 30.0)
            let troxlerFading = isReflecting ? 1.0 : max(0.2, 1.0 - ((timeElapsed - lastInteractionTime) / 10.0))
            
            ZStack {
                Color.white.ignoresSafeArea()
                
                // Retinal Noise Layer
                RetinalNoiseLayer(strain: strain, time: timeElapsed)
                    .ignoresSafeArea()
                
                // Biological Canvas Rendering (High Performance)
                Canvas { context, size in
                    let textSpacing: CGFloat = 60
                    let startY: CGFloat = 80
                    
                    for (i, paragraph) in paragraphs.enumerated() {
                        let basePosition = CGPoint(x: 40, y: startY + CGFloat(i) * textSpacing)
                        
                        // SYMPTOM: Diplopia (Vertical Ghosting)
                        if strain > 0.3 {
                            let drift = sin(timeElapsed * 1.5 + Double(i)) * 4 * strain
                            var ghostContext = context
                            ghostContext.opacity = 0.2 * strain * troxlerFading
                            ghostContext.draw(Text(paragraph).font(.system(size: 20, weight: .medium, design: .serif)), at: CGPoint(x: basePosition.x, y: basePosition.y + drift), anchor: .topLeading)
                        }
                        
                        // SYMPTOM: Liquid Lens (Wave Distortion)
                        var mainContext = context
                        mainContext.opacity = troxlerFading
                        
                        let waveX = sin(timeElapsed * 2.0 + Double(i)) * 2 * strain
                        let waveY = cos(timeElapsed * 1.5 + Double(i)) * 1 * strain
                        
                        mainContext.draw(
                            Text(paragraph)
                                .font(.system(size: 20, weight: .medium, design: .serif))
                                .foregroundColor(.black),
                            at: CGPoint(x: basePosition.x + waveX, y: basePosition.y + waveY),
                            anchor: .topLeading
                        )
                    }
                }
                .blur(radius: accommodationBlur)
                
                // 1. Ocular Blinks
                Color.black.opacity(blinkOpacity)
                    .ignoresSafeArea()
                
                // 2. Peripheral Tunneling
                VignetteLayer(strain: strain, size: geo.size)
                
                // 3. Floatous Physics
                FloaterLayer(floaters: $floaters, strain: strain, size: geo.size)
            }
            .onAppear {
                floaters = (0..<5).map { _ in spawnFloater(in: geo.size) }
            }
            .onReceive(timer) { _ in
                guard !isReflecting else { return }
                timeElapsed += 0.05
                
                // Accommodation Spasm
                if Int(timeElapsed * 20) % 250 == 0 {
                    withAnimation(.easeInOut(duration: 0.8)) { accommodationBlur = 4.0 * strain }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                        withAnimation(.easeInOut(duration: 1.5)) { accommodationBlur = 0.5 * strain }
                    }
                }
                
                // Blink Logic
                if Int(timeElapsed * 20) % 140 == 0 {
                    lastInteractionTime = timeElapsed // Reset Troxler on "blink"
                    withAnimation(.easeOut(duration: 0.1)) { blinkOpacity = 1.0 }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        withAnimation(.easeIn(duration: 0.3)) { blinkOpacity = 0 }
                    }
                }
                
                // Floater Update logic integrated in FloaterLayer for performance
            }
            .gesture(DragGesture(minimumDistance: 0).onChanged { _ in
                lastInteractionTime = timeElapsed // Troxler reset on user action
            })
        }
    }
    
    private func spawnFloater(in size: CGSize) -> BiologicalFloater {
        let start = CGPoint(x: CGFloat.random(in: 0...size.width), y: CGFloat.random(in: 0...size.height))
        return BiologicalFloater(
            segments: (0..<6).map { i in CGPoint(x: start.x + CGFloat(i * 4), y: start.y + CGFloat(i * 2)) },
            velocity: CGSize(width: CGFloat.random(in: -0.4...0.4), height: CGFloat.random(in: 0.1...0.6)),
            opacity: Double.random(in: 0.04...0.12)
        )
    }
}

// MARK: - Subcomponents

private struct RetinalNoiseLayer: View {
    let strain: Double
    let time: Double
    
    var body: some View {
        TimelineView(.animation) { _ in
            Canvas { context, size in
                for _ in 0..<Int(1500 * strain) {
                    let rect = CGRect(
                        x: CGFloat.random(in: 0...size.width),
                        y: CGFloat.random(in: 0...size.height),
                        width: 1.2,
                        height: 1.2
                    )
                    context.fill(Path(rect), with: .color(.black.opacity(Double.random(in: 0...0.08) * strain)))
                }
            }
        }
    }
}

private struct VignetteLayer: View {
    let strain: Double
    let size: CGSize
    
    var body: some View {
        RadialGradient(
            stops: [
                .init(color: .clear, location: 0.3 + (0.4 * (1.0 - strain))),
                .init(color: .black.opacity(0.85 * strain), location: 1.2)
            ],
            center: .center,
            startRadius: 0,
            endRadius: size.width * 1.1
        )
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .blur(radius: 30 * strain)
    }
}

private struct FloaterLayer: View {
    @Binding var floaters: [VisualStrainExperience.BiologicalFloater]
    let strain: Double
    let size: CGSize
    
    var body: some View {
        Canvas { context, size in
            for floater in floaters {
                var path = Path()
                if let first = floater.segments.first {
                    path.move(to: first)
                    for i in 1..<floater.segments.count {
                        path.addLine(to: floater.segments[i])
                    }
                }
                context.stroke(path, with: .color(.gray.opacity(floater.opacity * strain)), style: StrokeStyle(lineWidth: 1.5, lineCap: .round))
            }
        }
        .allowsHitTesting(false)
        .onChange(of: strain) { _ in
            updateFloaters()
        }
    }
    
    private func updateFloaters() {
        for i in 0..<floaters.count {
            floaters[i].segments[0].x += floaters[i].velocity.width
            floaters[i].segments[0].y += floaters[i].velocity.height
            
            for j in 1..<floaters[i].segments.count {
                let target = floaters[i].segments[j-1]
                floaters[i].segments[j].x += (target.x - floaters[i].segments[j].x) * 0.15
                floaters[i].segments[j].y += (target.y - floaters[i].segments[j].y) * 0.15
            }
            
            if floaters[i].segments[0].y > size.height + 50 { floaters[i].segments[0].y = -50 }
        }
    }
}

private struct OcularParagraph: View {
    let text: String
    let strain: Double
    let time: Double
    let index: Int
    let isReflecting: Bool
    let accommodationBlur: Double
    
    @State private var lineJitter: CGFloat = 0
    
    var body: some View {
        ZStack {
            // Cyan Channel Ghost
            Text(text)
                .foregroundColor(.cyan.opacity(0.3 * strain))
                .offset(x: isReflecting ? 0 : CGFloat(sin(time * 2 + Double(index)) * 2 * strain))
            
            // Red Channel Ghost
            Text(text)
                .foregroundColor(.red.opacity(0.3 * strain))
                .offset(x: isReflecting ? 0 : CGFloat(-sin(time * 2 + Double(index)) * 2 * strain))
            
            // Core Text
            Text(text)
                .foregroundColor(.black.opacity(isReflecting ? 1.0 : (0.8 - (0.3 * strain))))
                .kerning(isReflecting ? 0 : CGFloat(sin(time * 1.5 + Double(index)) * 2 * strain))
        }
        .font(.system(size: 22, weight: .medium, design: .serif))
        .multilineTextAlignment(.leading)
        .lineSpacing(isReflecting ? 6 : 6 + (sin(time * 0.8) * 4 * strain))
        .blur(radius: isReflecting ? 0 : (CGFloat(sin(time * 0.5 + Double(index)) * 1.0 * strain) + accommodationBlur))
        .scaleEffect(isReflecting ? 1.0 : 1.0 + (sin(time * 0.3) * 0.01 * strain))
        // High-frequency jitter driven by the central timer instead of a local Timer
        .offset(y: isReflecting ? 0 : (sin(time * 5 + Double(index)) * 1.5 * strain))
    }
}



struct ColorPerceptionExperience: View {
    let isReflecting: Bool
    @Environment(\.accessibilityReduceMotion) var reduceMotion

    @State private var timeElapsed: Double = 0
    let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()

    @State private var targetIndex: Int = 0
    @State private var baseHue: Double = 0.55
    @State private var baseSaturation: Double = 0.75
    @State private var baseBrightness: Double = 0.85
    @State private var roundId: Int = 0
    @State private var recognizedCount: Int = 0
    @State private var countOpacity: Double = 0.0
    @State private var transitioning: Bool = false
    @State private var backgroundHueOffset: Double = 0.0

    let columns = Array(repeating: GridItem(.flexible(), spacing: 10), count: 4)
    private let tileCount = 16

    private var roundProgress: Double {
        let r = Double(roundId)
        if r <= 3 { return 0.0 }
        if r <= 6 { return (r - 3.0) / 3.0 * 0.5 }
        return min(0.5 + (r - 6.0) / 8.0 * 0.5, 1.0)
    }

    private var hueDelta: Double {
        let r = roundId
        if r <= 1 { return 0.14 }
        if r == 2 { return 0.12 }
        if r == 3 { return 0.10 }
        if r == 4 { return 0.06 }
        if r == 5 { return 0.045 }
        if r == 6 { return 0.03 }
        let late = Double(r - 6)
        return max(0.004, 0.02 - late * 0.002)
    }

    private var saturationForRound: Double {
        let r = roundId
        if r <= 3 { return 0.75 }
        if r <= 6 { return 0.65 - Double(r - 3) * 0.05 }
        return max(0.35, 0.50 - Double(r - 6) * 0.02)
    }

    private var brightnessForRound: Double {
        let r = roundId
        if r <= 3 { return 0.85 }
        if r <= 6 { return 0.80 - Double(r - 3) * 0.03 }
        return max(0.55, 0.71 - Double(r - 6) * 0.02)
    }

    private var contextStrength: Double {
        let r = roundId
        if r <= 3 { return 0.0 }
        if r <= 6 { return Double(r - 3) / 3.0 * 0.4 }
        return min(0.4 + Double(r - 6) / 8.0 * 0.6, 1.0)
    }

    private var contextualBgHue: Double {
        let drift = sin(timeElapsed * 0.02) * 0.08 * contextStrength
        return baseHue + backgroundHueOffset + drift
    }

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color(
                    hue: fract(contextualBgHue),
                    saturation: max(0.03, 0.18 * contextStrength),
                    brightness: 0.10 + 0.08 * contextStrength
                )
                .ignoresSafeArea()
                .animation(reduceMotion ? nil : .easeInOut(duration: 2.0), value: roundId)

                VStack(spacing: 0) {
                    Spacer()

                    Text("Find the different shade")
                        .font(.system(size: 13, weight: .regular, design: .default))
                        .textCase(.uppercase)
                        .kerning(2.5)
                        .foregroundColor(.white.opacity(0.35))
                        .padding(.bottom, 28)

                    let gridSize = min(geo.size.width - 56, geo.size.height * 0.55)

                    LazyVGrid(columns: columns, spacing: 10) {
                        ForEach(0..<tileCount, id: \.self) { index in
                            let tileColor = colorForTile(index: index)
                            RoundedRectangle(cornerRadius: 12)
                                .fill(tileColor)
                                .aspectRatio(1.0, contentMode: .fit)
                                .onTapGesture {
                                    guard !transitioning else { return }
                                    handleTap(index)
                                }
                        }
                    }
                    .frame(width: gridSize, height: gridSize)
                    .padding(.horizontal, 28)
                    .opacity(transitioning ? 0.0 : 1.0)
                    .animation(reduceMotion ? nil : .easeInOut(duration: 0.5), value: transitioning)

                    Spacer()
                }

                VStack {
                    HStack {
                        Spacer()
                        Text("Recognized · \(recognizedCount)")
                            .font(.system(size: 12, weight: .regular, design: .monospaced))
                            .foregroundColor(.white.opacity(max(0.15, 0.3 - roundProgress * 0.15)))
                            .opacity(countOpacity)
                            .padding(.top, 56)
                            .padding(.trailing, 24)
                    }
                    Spacer()
                }
            }
        }
        .onAppear {
            generateRound()
            withAnimation(.easeInOut(duration: 1.0)) {
                countOpacity = 1.0
            }
        }
        .onReceive(timer) { _ in
            guard !isReflecting else { return }
            timeElapsed += 0.1
            backgroundHueOffset = sin(timeElapsed * 0.015) * 0.06 * contextStrength
        }
    }

    private func colorForTile(index: Int) -> Color {
        let ctx = contextStrength
        let contextShift = sin(timeElapsed * 0.025 + Double(index) * 0.4) * 0.018 * ctx
        let sat = max(0.1, saturationForRound + sin(Double(index) * 0.7) * 0.03 * ctx)
        let brt = max(0.2, brightnessForRound + cos(Double(index) * 0.5) * 0.02 * ctx)

        if index == targetIndex {
            let direction: Double = (roundId % 2 == 0) ? 1.0 : -1.0
            let delta = hueDelta
            let oddHue = baseHue + delta * direction + contextShift
            let oddSat = sat + delta * 0.35 * direction
            let oddBrt = brt - delta * 0.2 * direction
            return Color(
                hue: fract(oddHue),
                saturation: clamp01(oddSat),
                brightness: clamp01(oddBrt)
            )
        }

        return Color(
            hue: fract(baseHue + contextShift),
            saturation: clamp01(sat),
            brightness: clamp01(brt)
        )
    }

    private func handleTap(_ index: Int) {
        transitioning = true

        if index == targetIndex {
            recognizedCount += 1
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            generateRound()
            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.5)) {
                transitioning = false
            }
        }
    }

    private func generateRound() {
        roundId += 1
        targetIndex = Int.random(in: 0..<tileCount)

        let huePool: [Double] = [0.0, 0.08, 0.12, 0.2, 0.3, 0.42, 0.55, 0.62, 0.72, 0.85, 0.92]
        baseHue = huePool.randomElement() ?? 0.55

        baseSaturation = saturationForRound + Double.random(in: -0.03...0.03)
        baseBrightness = brightnessForRound + Double.random(in: -0.03...0.03)
    }

    private func fract(_ v: Double) -> Double {
        v - floor(v)
    }

    private func clamp01(_ v: Double) -> Double {
        max(0.0, min(1.0, v))
    }
}

struct FocusTunnelExperience: View {
    let isReflecting: Bool
    @Environment(\.accessibilityReduceMotion) var reduceMotion
    
    @State private var timeElapsed: Double = 0
    @State private var powerOutput: Double = 45.0
    @State private var coolantLevel: Double = 98.0
    @State private var coreStability: Double = 100.0
    @State private var alertsIgnored: Int = 0
    @State private var glitchOffset: CGFloat = 0
    @State private var shakeOffset: CGSize = .zero
    @State private var ghostAlerts: [GhostAlert] = []
    
    struct GhostAlert: Identifiable {
        let id = UUID()
        var pos: CGPoint
        var opacity: Double = 0
    }
    
    let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    
    var progress: Double {
        // Aggressive collapse over 10 seconds, starting after 3 seconds
        let p = (timeElapsed - 3.0) / 10.0
        return max(0, min(p, 1.0))
    }
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                // LAYER 0: VORTEX BACKGROUND
                VortexBackground(time: timeElapsed, progress: progress)
                
                // PHASE 1 & 3: REACTOR CONSOLE (Baseline & Misses)
                ReactorConsoleLayer(
                    timeElapsed: timeElapsed,
                    coolantLevel: coolantLevel,
                    coreStability: coreStability,
                    isReflecting: isReflecting,
                    glitchOffset: glitchOffset
                )
                
                // PHASE 2 & 5: GHOST ALERTS (Peripheral misdirection)
                ForEach(ghostAlerts) { alert in
                    Text("!! PERIPHERAL BREACH !!")
                        .font(.system(size: 10, weight: .black, design: .monospaced))
                        .foregroundColor(.red)
                        .padding(8)
                        .background(Color.red.opacity(0.1))
                        .position(alert.pos)
                        .opacity(alert.opacity)
                }
                
                // PHASE 2: TUNNEL COLLAPSE
                ReactorFocusMask(progress: progress, isReflecting: isReflecting, size: geo.size, time: timeElapsed)
                
                // PHASE 4: PRIMARY TASK (Central Misdirection)
                VStack(spacing: 12) {
                    Text("CORE OUTPUT")
                        .font(.system(.caption2, design: .monospaced))
                        .opacity(0.6)
                    
                    Text("\(String(format: "%.1f", powerOutput))% MW")
                        .font(.system(size: 32, weight: .bold, design: .monospaced))
                        .foregroundColor(.accentColor)
                    
                    Button(action: {
                        powerOutput = min(99.9, powerOutput + 1.2)
                    }) {
                        Text("OPTIMIZE OUTPUT")
                            .font(.system(size: 14, weight: .bold, design: .monospaced))
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                            .background(Color.accentColor.opacity(0.1))
                            .overlay(RoundedRectangle(cornerRadius: 4).stroke(Color.accentColor.opacity(0.4), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                    
                    Text("Core sync active • Normal")
                        .font(.system(size: 10, design: .monospaced))
                        .italic()
                        .opacity(0.3)
                }
                .padding(24)
                .background(Color.black.opacity(0.4))
                .cornerRadius(4)
                .position(x: geo.size.width/2, y: geo.size.height/2)
                .offset(glitchOffset != 0 ? CGSize(width: .random(in: -5...5), height: 0) : .zero)
                
                // LAYER 10: SCANLINES & INTERFERENCE
                ScanlineOverlay()
            }
            .offset(shakeOffset)
            .background(Color(white: 0.02))
            .onReceive(timer) { _ in
                guard !isReflecting else { return }
                timeElapsed += 0.1
                
                // Natural decay of output to keep user busy
                if powerOutput > 20 { powerOutput -= 0.12 }
                
                // PHASE 3: PERIPHERAL DECAY (Hidden from user)
                if timeElapsed > 8 {
                    coolantLevel = max(0, coolantLevel - 1.5)
                }
                
                if coolantLevel < 20 {
                    coreStability = max(0, coreStability - 0.8)
                }
                
                // NEW: Glitch logic
                if coreStability < 40 && Int(timeElapsed * 10) % 15 == 0 {
                    glitchOffset = CGFloat.random(in: -4...4)
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { glitchOffset = 0 }
                }
                
                // NEW: Shake logic
                if coreStability < 30 {
                    shakeOffset = CGSize(width: .random(in: -3...3), height: .random(in: -3...3))
                } else {
                    shakeOffset = .zero
                }
                
                // NEW: Ghost Alerts spawning
                if progress > 0.4 && Int(timeElapsed * 10) % 40 == 0 {
                    let x = Bool.random() ? CGFloat.random(in: 20...60) : geo.size.width - CGFloat.random(in: 20...60)
                    let y = Bool.random() ? CGFloat.random(in: 20...60) : geo.size.height - CGFloat.random(in: 20...60)
                    let newAlert = GhostAlert(pos: CGPoint(x: x, y: y))
                    ghostAlerts.append(newAlert)
                    
                    let id = newAlert.id
                    withAnimation(.easeIn(duration: 0.5)) {
                        if let idx = ghostAlerts.firstIndex(where: { $0.id == id }) { ghostAlerts[idx].opacity = 0.8 }
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                        withAnimation(.easeOut(duration: 1.0)) {
                            if let idx = ghostAlerts.firstIndex(where: { $0.id == id }) { ghostAlerts[idx].opacity = 0 }
                        }
                    }
                }
            }
        }
    }
}

private struct ReactorConsoleLayer: View {
    let timeElapsed: Double
    let coolantLevel: Double
    let coreStability: Double
    let isReflecting: Bool
    let glitchOffset: CGFloat
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                // Grid Background
                GridPattern()
                    .stroke(Color.primary.opacity(0.05), lineWidth: 1)
                
                // Top Right: Coolant System (DANGER ZONE)
                VStack(alignment: .trailing, spacing: 4) {
                    Text("COOLANT SYSTEM")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                    
                    Rectangle()
                        .fill(coolantLevel < 30 ? Color.red : Color.blue.opacity(0.6))
                        .frame(width: 120, height: 8)
                        .scaleEffect(x: coolantLevel / 100.0, y: 1.0, anchor: .trailing)
                    
                    Text("\(Int(coolantLevel))% VOLUME")
                        .font(.system(size: 12, design: .monospaced))
                        .foregroundColor(coolantLevel < 30 ? .red : .primary)
                    
                    if coolantLevel < 20 {
                        Text("!! CRITICAL LOSS !!")
                            .font(.system(size: 10, weight: .black, design: .monospaced))
                            .foregroundColor(.red)
                            .opacity(sin(timeElapsed * 10) > 0 ? 1 : 0)
                    }
                }
                .position(x: geo.size.width - 80, y: 100)
                
                // Bottom Left: Core Stability
                VStack(alignment: .leading, spacing: 4) {
                    Text("CORE STABILITY")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                    
                    Text("\(String(format: "%.1f", coreStability))%")
                        .font(.system(size: 20, weight: .light, design: .monospaced))
                        .foregroundColor(coreStability < 50 ? .red : .accentColor)
                    
                    if coreStability < 30 {
                        Text("CONTAINMENT BREACH IMMINENT")
                            .font(.system(size: 8, weight: .bold, design: .monospaced))
                            .foregroundColor(.red)
                    }
                }
                .position(x: 100, y: geo.size.height - 120)
                .offset(y: glitchOffset)
                
                // Peripheral Noise: System Logs
                VStack(alignment: .leading, spacing: 2) {
                    ForEach(0..<8) { i in
                        Text("> SYS_LOG_\(i): CHANNEL_\(Int(timeElapsed) % 4) ACTIVE")
                            .font(.system(size: 8, design: .monospaced))
                            .opacity(0.2)
                    }
                }
                .position(x: 80, y: 200)
                
                // EMERGENCY SHUTDOWN (The button that matters, but becomes invisible)
                Button(action: {}) {
                    Text("EMERGENCY SHUTDOWN")
                        .font(.system(size: 12, weight: .black, design: .monospaced))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.red)
                        .cornerRadius(4)
                }
                .position(x: 120, y: 80)
            }
        }
    }
}

private struct ReactorFocusMask: View {
    let progress: Double
    let isReflecting: Bool
    let size: CGSize
    let time: Double
    
    var body: some View {
        Canvas { context, size in
            let center = CGPoint(x: size.width / 2, y: size.height / 2)
            let maxDim = max(size.width, size.height)
            
            // Constrict to a focus window around the central MW readout
            let targetRadius = 180.0
            let baseRadius = maxDim * 1.8 - (progress * (maxDim * 1.8 - targetRadius))
            let currentRadius = isReflecting ? maxDim * 2.0 : baseRadius
            
            context.fill(Path(CGRect(origin: .zero, size: size)), with: .color(.black))
            context.blendMode = .destinationOut
            
            // Multiple layers for a soft, shimmering edge
            for i in 0..<8 {
                let jitter = sin(time * 3 + Double(i)) * (isReflecting ? 0 : 8 * progress)
                let layerRadius = currentRadius + CGFloat(i * 15)
                let scale = 1.0 + (sin(time * 2 + Double(i)) * 0.02 * progress)
                
                var path = Path()
                path.addEllipse(in: CGRect(
                    x: center.x - (layerRadius * scale)/2 + jitter,
                    y: center.y - (layerRadius * scale)/2 - jitter,
                    width: layerRadius * scale,
                    height: layerRadius * scale
                ))
                context.fill(path, with: .color(.black.opacity(1.0 - Double(i) * 0.1)))
            }
        }
        .background(
            ZStack {
                Color.black.opacity(isReflecting ? 0.6 : 0.995)
                
                // Heat Shimmer / Depth Gradient
                RadialGradient(
                    colors: [
                        .clear,
                        .accentColor.opacity(0.1 * progress),
                        .black.opacity(0.8)
                    ],
                    center: .center,
                    startRadius: 0,
                    endRadius: max(size.width, size.height) / 1.4
                )
            }
        )
        .compositingGroup()
    }
}

private struct GridPattern: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let step: CGFloat = 40
        for x in stride(from: 0, through: rect.width, by: step) {
            path.move(to: CGPoint(x: x, y: 0))
            path.addLine(to: CGPoint(x: x, y: rect.height))
        }
        for y in stride(from: 0, through: rect.height, by: step) {
            path.move(to: CGPoint(x: 0, y: y))
            path.addLine(to: CGPoint(x: rect.width, y: y))
        }
        return path
    }
}

// MARK: - Immersion Components

private struct VortexBackground: View {
    let time: Double
    let progress: Double
    
    var body: some View {
        TimelineView(.animation) { timeline in
            Canvas { context, size in
                let center = CGPoint(x: size.width/2, y: size.height/2)
                let count = 40
                
                for i in 0..<count {
                    let angle = Double(i) * (.pi * 2 / Double(count)) + (time * 0.2)
                    let radius = (sin(time * 0.5 + Double(i) * 0.1) * 50) + (size.width * 0.4)
                    let pX = center.x + radius * cos(angle)
                    let pY = center.y + radius * sin(angle)
                    
                    // Particles move towards center as progress increases
                    let finalX = pX + (center.x - pX) * (progress * 0.5)
                    let finalY = pY + (center.y - pY) * (progress * 0.5)
                    
                    context.fill(
                        Path(ellipseIn: CGRect(x: finalX, y: finalY, width: 2, height: 2)),
                        with: .color(.accentColor.opacity(0.1 + (0.2 * progress)))
                    )
                }
            }
        }
        .allowsHitTesting(false)
    }
}

private struct ScanlineOverlay: View {
    var body: some View {
        GeometryReader { geo in
            ZStack {
                // Vertical Scanlines
                Path { path in
                    let step: CGFloat = 8
                    for x in stride(from: 0, through: geo.size.width, by: step) {
                        path.move(to: CGPoint(x: x, y: 0))
                        path.addLine(to: CGPoint(x: x, y: geo.size.height))
                    }
                }
                .stroke(Color.white.opacity(0.03), lineWidth: 1)
                
                // Static Noise / Interference
                Rectangle()
                    .fill(.ultraThinMaterial)
                    .opacity(0.02)
            }
        }
        .allowsHitTesting(false)
    }
}

struct ReadingStabilityExperience: View {
    let isReflecting: Bool
    @State private var time: Double = 0
    let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    
    private let paragraphs = [
        "The eye does not glide across the page; it moves in rapid jumps called saccades, anchored by brief moments of stillness.",
        "When this anchoring fails, words begin to drift. A line of text becomes a moving target, requiring constant recalculation.",
        "Compensating for this instability is an invisible labor. Every sentence becomes a puzzle of reconstruction and effort.",
        "Comprehension is the first casualty of tracking instability. When the focus shifts, the meaning often slips away alongside it."
    ]
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.opacity(0.02).ignoresSafeArea()
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 50) {
                        ForEach(0..<paragraphs.count, id: \.self) { i in
                            EnhancedReadingParagraph(
                                text: paragraphs[i],
                                index: i,
                                time: time,
                                isReflecting: isReflecting
                            )
                        }
                    }
                    .padding(40)
                    .padding(.top, 40)
                }
                .scrollDisabled(true)
                
                // Ocular "Floaters" and Vision Washes
                if !isReflecting {
                    VisionDisturbanceLayer(time: time, size: geo.size)
                }
            }
        }
        .onReceive(timer) { _ in
            guard !isReflecting else { return }
            time += 0.1
        }
    }
}

private struct EnhancedReadingParagraph: View {
    let text: String
    let index: Int
    let time: Double
    let isReflecting: Bool
    
    var body: some View {
        // Line-Skipping Simulation
        let yOffset = isReflecting ? 0 : (sin(time * 0.4 + Double(index)) > 0.96 ? CGFloat.random(in: -40...40) : 0)
        
        VStack(alignment: .leading, spacing: 12) {
            Text(text)
                .font(.system(size: 24, weight: .medium, design: .serif))
                .lineSpacing(12 + (isReflecting ? 0 : sin(time * 0.8) * 6))
                .kerning(isReflecting ? 0 : cos(time * 0.5 + Double(index)) * 2.0)
                .blur(radius: isReflecting ? 0 : max(0, sin(time * 1.2 + Double(index)) * 1.5))
                .opacity(isReflecting ? 1.0 : 0.7 + sin(time * 0.3) * 0.2)
                .offset(y: yOffset)
                .animation(.spring(response: 0.4, dampingFraction: 0.5), value: yOffset)
                .overlay(
                    // Inner "Glimmer" effect on text
                    Text(text)
                        .font(.system(size: 24, weight: .medium, design: .serif))
                        .lineSpacing(12 + (isReflecting ? 0 : sin(time * 0.8) * 6))
                        .kerning(isReflecting ? 0 : cos(time * 0.5 + Double(index)) * 2.0)
                        .foregroundColor(.accentColor.opacity(0.15))
                        .offset(x: isReflecting ? 0 : sin(time * 2.0) * 2)
                        .mask(Text(text).font(.system(size: 24, weight: .medium, design: .serif)))
                        .opacity(isReflecting ? 0 : 1)
                )
        }
    }
}

private struct VisionDisturbanceLayer: View {
    let time: Double
    let size: CGSize
    
    var body: some View {
        ZStack {
            // Focus Fog
            ForEach(0..<2) { i in
                Circle()
                    .fill(RadialGradient(colors: [.white.opacity(0.1), .clear], center: .center, startRadius: 0, endRadius: 150))
                    .frame(width: 300, height: 300)
                    .blur(radius: 40)
                    .offset(
                        x: sin(time * 0.2 + Double(i)) * size.width/2.5,
                        y: cos(time * 0.15 + Double(i)) * size.height/3
                    )
            }
            
            // Subtle Chrome Aberration simulated via a thin moving line
            Rectangle()
                .fill(LinearGradient(colors: [.clear, .blue.opacity(0.05), .clear], startPoint: .top, endPoint: .bottom))
                .frame(height: 100)
                .offset(y: CGFloat(Int(time * 100) % Int(size.height * 2)) - size.height)
                .allowsHitTesting(false)
        }
    }
}

// REPLACING BODY OF ReadingStabilityExperience with the stable version

struct MemoryLoadExperience: View {
    let isReflecting: Bool
    @State private var pattern: [Int] = (0..<9).map { _ in Int.random(in: 0...1) }
    @State private var phase: Int = 0 // 0: Imprint, 1: Interfere, 2: Recall
    @State private var userPattern: [Int] = Array(repeating: 0, count: 9)
    
    // Feedback & Continuous State
    enum Feedback { case success, failure }
    @State private var feedback: Feedback? = nil
    
    // Interference State
    @State private var currentQuestion: LogicQuestion = LogicQuestion.generate()
    @State private var questionsSolved: Int = 0
    
    // Timing and Animation
    @State private var time: Double = 0
    let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        VStack(spacing: 30) {
            Text(statusText)
                .font(.system(.title3, design: .monospaced))
                .foregroundColor(feedback == .failure ? .red : .accentColor)
                .frame(height: 40)
            
            ZStack {
                if phase == 1 && !isReflecting {
                    // PHASE 2: ACTIVE INTERFERENCE
                    VStack(spacing: 20) {
                        Text("SOLVE TO MAINTAIN BUFFER")
                            .font(.caption)
                            .opacity(0.6)
                        
                        Text(currentQuestion.text)
                            .font(.system(size: 32, weight: .bold, design: .monospaced))
                        
                        HStack(spacing: 20) {
                            Button("YES") { checkAnswer(true) }
                            Button("NO") { checkAnswer(false) }
                        }
                        .buttonStyle(.borderedProminent)
                        
                        Text("Questions Solved: \(questionsSolved)")
                            .font(.caption2)
                            .opacity(0.4)
                    }
                    .transition(.asymmetric(insertion: .scale.combined(with: .opacity), removal: .opacity))
                } else {
                    // PHASE 1 & 3: GRID (Floating/Noisy)
                    memoryGrid
                        .blur(radius: (phase == 2 && !isReflecting) ? 1.5 : 0)
                        .overlay(recallNoiseLayer)
                        .offset(x: feedback == .failure ? sin(time * 60) * 5 : 0) // Failure shake
                        .scaleEffect(feedback == .success ? 1.05 : 1.0) // Success pulse
                }
            }
            .frame(width: 350, height: 350)
            
            if phase == 2 && !isReflecting {
                Button(action: submitPattern) {
                    Text(feedback == nil ? "SUBMIT FOR BUFFER CHECK" : (feedback == .success ? "SUCCESS" : "FAILURE"))
                        .font(.system(.subheadline, design: .monospaced))
                        .fontWeight(.bold)
                        .padding(.horizontal, 30)
                        .padding(.vertical, 12)
                        .background(feedback == nil ? Color.accentColor : (feedback == .success ? .indigo : .red))
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .disabled(feedback != nil)
                .transition(.scale.combined(with: .opacity))
            } else if isReflecting {
                // COMPARATIVE REFLECTION
                HStack(spacing: 40) {
                    MiniPatternGrid(pattern: pattern, title: "ACTUAL")
                    MiniPatternGrid(pattern: userPattern, title: "YOURS")
                }
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .onReceive(timer) { _ in
            guard !isReflecting else { return }
            time += 0.1
            
            if phase == 0 && time >= 5.0 {
                withAnimation { phase = 1 }
            } else if phase == 1 && time >= 15.0 {
                withAnimation { phase = 2 }
            }
        }
    }
    
    private var memoryGrid: some View {
        LazyVGrid(columns: Array(repeating: GridItem(.fixed(80), spacing: 20), count: 3), spacing: 20) {
            ForEach(0..<9) { i in
                RoundedRectangle(cornerRadius: 12)
                    .fill(cellColor(at: i))
                    .frame(width: 80, height: 80)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(feedback == nil ? Color.primary.opacity(0.1) : (feedback == .success ? Color.indigo : Color.red).opacity(0.3), lineWidth: 1))
                    .onTapGesture {
                        if phase == 2 && !isReflecting && feedback == nil {
                            userPattern[i] = userPattern[i] == 1 ? 0 : 1
                        }
                    }
            }
        }
        // Spatial Drift: Subtle movement to break screen-edge referencing
        .rotationEffect(.degrees(isReflecting ? 0 : sin(time * 0.5) * 3))
        .offset(x: isReflecting ? 0 : cos(time * 0.4) * 10, y: isReflecting ? 0 : sin(time * 0.6) * 10)
    }
    
    private var recallNoiseLayer: some View {
        Group {
            if phase == 2 && !isReflecting && feedback == nil {
                Canvas { context, size in
                    for _ in 0..<500 {
                        let x = CGFloat.random(in: 0...size.width)
                        let y = CGFloat.random(in: 0...size.height)
                        context.fill(Path(CGRect(x: x, y: y, width: 1, height: 1)), with: .color(.primary.opacity(0.1)))
                    }
                }
                .allowsHitTesting(false)
            }
        }
    }
    
    private var statusText: String {
        if isReflecting { return "COMPARISON" }
        if feedback == .success { return "BUFFER RECOVERED" }
        if feedback == .failure { return "BUFFER CORRUPTED" }
        
        switch phase {
        case 0: return "IMPRINTING BUFFER..."
        case 1: return "INTERFERENCE DETECTED"
        case 2: return "RECALL FRAGMENTED"
        default: return ""
        }
    }
    
    private func cellColor(at i: Int) -> Color {
        if phase == 0 {
            return pattern[i] == 1 ? .accentColor : Color.gray.opacity(0.1)
        } else if phase == 2 {
            return userPattern[i] == 1 ? (feedback == .failure ? .red : .accentColor) : Color.gray.opacity(0.1)
        }
        return Color.gray.opacity(0.05)
    }
    
    private func checkAnswer(_ answer: Bool) {
        if answer == currentQuestion.answer {
            questionsSolved += 1
        }
        withAnimation(.spring()) {
            currentQuestion = LogicQuestion.generate()
        }
    }
    
    private func submitPattern() {
        if userPattern == pattern {
            withAnimation(.spring()) { feedback = .success }
        } else {
            withAnimation(.spring()) { feedback = .failure }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
            withAnimation {
                pattern = (0..<9).map { _ in Int.random(in: 0...1) }
                userPattern = Array(repeating: 0, count: 9)
                phase = 0
                time = 0
                feedback = nil
            }
        }
    }
}

private struct LogicQuestion {
    let text: String
    let answer: Bool
    
    static func generate() -> LogicQuestion {
        let ops = ["+", "-", ">", "<"]
        let op = ops.randomElement()!
        let a = Int.random(in: 1...20)
        let b = Int.random(in: 1...20)
        
        switch op {
        case "+":
            let sum = a + b
            let visibleSum = Bool.random() ? sum : sum + Int.random(in: -2...2)
            return LogicQuestion(text: "\(a) + \(b) = \(visibleSum)?", answer: sum == visibleSum)
        case ">":
            return LogicQuestion(text: "\(a) > \(b)?", answer: a > b)
        case "<":
            return LogicQuestion(text: "\(a) < \(b)?", answer: a < b)
        default:
            let diff = a - b
            let visibleDiff = Bool.random() ? diff : diff + Int.random(in: -2...2)
            return LogicQuestion(text: "\(a) - \(b) = \(visibleDiff)?", answer: diff == visibleDiff)
        }
    }
}

private struct MiniPatternGrid: View {
    let pattern: [Int]
    let title: String
    
    var body: some View {
        VStack(spacing: 12) {
            Text(title)
                .font(.system(size: 10, weight: .bold, design: .monospaced))
                .opacity(0.6)
            
            LazyVGrid(columns: Array(repeating: GridItem(.fixed(20), spacing: 4), count: 3), spacing: 4) {
                ForEach(0..<9) { i in
                    Rectangle()
                        .fill(pattern[i] == 1 ? Color.accentColor : Color.gray.opacity(0.2))
                        .frame(width: 20, height: 20)
                        .cornerRadius(2)
                }
            }
        }
    }
}

struct FocusDistractionExperience: View {
    let isReflecting: Bool
    
    @State private var timeDelta: Double = 0
    // Distractors: fewer, more surgical.
    @State private var distractorData: [SurgicalDistractorState] = [
        SurgicalDistractorState(id: 0, label: "URGENT: 1 New Message", freqX: 0.15, freqY: 0.22),
        SurgicalDistractorState(id: 1, label: "Alert: Battery Low (10%)", freqX: 0.25, freqY: 0.12),
        SurgicalDistractorState(id: 2, label: "DANGER: Signal Lost", freqX: 0.08, freqY: 0.31)
    ]
    
    // Focus Anchor state
    @State private var anchorDrift: CGSize = .zero
    @State private var stability: Double = 1.0
    
    let timer = Timer.publish(every: 0.05, on: .main, in: .common).autoconnect()
    
    struct SurgicalDistractorState: Identifiable {
        let id: Int
        let label: String
        let freqX: Double
        let freqY: Double
        var position: CGPoint = .zero
        var phase: Double = Double.random(in: 0...Double.pi * 2)
    }
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                // Background Depth
                Color.black.opacity(0.8).ignoresSafeArea()
                
                // Distractors (Surgical Banners)
                ForEach(distractorData) { state in
                    SurgicalDistractorView(
                        isReflecting: isReflecting,
                        time: timeDelta,
                        size: geo.size,
                        label: state.label,
                        freqX: state.freqX,
                        freqY: state.freqY,
                        phase: state.phase
                    )
                }
                
                // Focal Anchor System
                FocusSurgicalCard(
                    isReflecting: isReflecting,
                    time: timeDelta,
                    anchorDrift: $anchorDrift,
                    stability: $stability,
                    center: CGPoint(x: geo.size.width/2, y: geo.size.height/2)
                )
            }
        }
        .onReceive(timer) { _ in
            guard !isReflecting else { return }
            timeDelta += 0.05
            
            // Subtle drift of the internal "Anchor" to require active correction
            withAnimation(.linear(duration: 0.05)) {
                anchorDrift.width += CGFloat(sin(timeDelta * 0.4) * 0.8)
                anchorDrift.height += CGFloat(cos(timeDelta * 0.3) * 0.8)
                
                // Stability degrades if the user doesn't "correct" (resetting via tap)
                let driftMag = sqrt(pow(anchorDrift.width, 2) + pow(anchorDrift.height, 2))
                stability = max(0.5, 1.0 - (driftMag / 150))
            }
        }
    }
}

private struct FocusSurgicalCard: View {
    let isReflecting: Bool
    let time: Double
    @Binding var anchorDrift: CGSize
    @Binding var stability: Double
    let center: CGPoint
    
    @State private var isCorrecting = false
    
    var body: some View {
        VStack(spacing: 20) {
            // Stability Meter
            if !isReflecting {
                HStack(spacing: 8) {
                    Text("COGNITIVE STABILITY")
                        .font(.system(size: 8, weight: .bold, design: .monospaced))
                        .opacity(0.5)
                    
                    ZStack(alignment: .leading) {
                        Rectangle().fill(Color.white.opacity(0.1)).frame(width: 100, height: 4)
                        Rectangle().fill(stability < 0.7 ? Color.red : Color.accentColor)
                            .frame(width: CGFloat(stability * 100), height: 4)
                    }
                }
            }
            
            ZStack {
                // The Focus Ring (Visual Guide)
                Circle()
                    .stroke(Color.white.opacity(0.1), lineWidth: 1)
                    .frame(width: 40, height: 40)
                    .offset(anchorDrift)
                
                // The Active Target (User must keep this centered)
                Circle()
                    .fill(stability < 0.7 ? Color.red.opacity(0.8) : Color.accentColor.opacity(0.8))
                    .frame(width: 12, height: 12)
                    .offset(anchorDrift)
                    .shadow(color: stability < 0.7 ? .red : .accentColor, radius: 10)
                
                VStack(spacing: 16) {
                    Text("Involuntary attention capture arises when high-priority social signals (like notifications) compete for the same neural resources as your focal task.")
                        .font(.system(size: 16, weight: .medium, design: .serif))
                    
                    Text("Keep the anchor centered by tapping the card while reading.")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .foregroundColor(.accentColor)
                        .opacity(sin(time * 5) > 0 ? 1 : 0.5)
                }
                .multilineTextAlignment(.center)
                .padding(32)
                .background(.ultraThinMaterial)
                .cornerRadius(24)
                .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.1), lineWidth: 0.5))
                .blur(radius: (1.0 - stability) * 10) // Blur text as stability drops
                .scaleEffect(0.95 + (stability * 0.05))
            }
            .onTapGesture {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) {
                    anchorDrift = .zero
                    isCorrecting = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    isCorrecting = false
                }
            }
        }
        .frame(width: 320)
        .position(x: center.x, y: center.y)
    }
}

private struct SurgicalDistractorView: View {
    let isReflecting: Bool
    let time: Double
    let size: CGSize
    let label: String
    let freqX: Double
    let freqY: Double
    let phase: Double
    
    var body: some View {
        // Lissajous Curve Pathing for "Liquid" motion
        let x = size.width/2 + CGFloat(sin(time * freqX * 8 + phase)) * (size.width/2.5)
        let y = size.height/2 + CGFloat(cos(time * freqY * 8 + phase)) * (size.height/2.5)
        
        HStack(spacing: 12) {
            // App Icon Placeholder
            RoundedRectangle(cornerRadius: 6)
                .fill(Color.red)
                .frame(width: 24, height: 24)
                .overlay(Image(systemName: "bell.fill").font(.system(size: 12)).foregroundColor(.white))
            
            VStack(alignment: .leading, spacing: 1) {
                Text("MESSAGE")
                    .font(.system(size: 8, weight: .black))
                    .foregroundColor(.secondary)
                Text(label)
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundColor(.primary)
            }
            
            Spacer()
            
            Text("now")
                .font(.system(size: 8))
                .foregroundColor(.secondary)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .frame(width: 180)
        .background(.regularMaterial)
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.4), radius: 10, x: 0, y: 5)
        .position(x: x, y: y)
        .opacity(isReflecting ? 0 : 1)
        .blur(radius: isReflecting ? 20 : 0)
    }
}

struct CognitiveLoadExperience: View {
    let isReflecting: Bool
    
    // Core state
    @State private var tasks: [CognitiveTask] = []
    @State private var taskCounter: Int = 0 // Used purely for unique IDs to ensure fresh offset generation
    @State private var timeElapsed: Double = 0
    @State private var lastSpawnTime: Double = 0
    
    // Timers
    // Base arrival rate. We'll use a slightly random interval in the actual logic,
    // but this timer drives the check.
    let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    
    struct CognitiveTask: Identifiable, Equatable {
        let id: Int
        let type: TaskType
        var isCompleting: Bool = false
        // Visual positioning
        let xOffset: CGFloat
        let yOffset: CGFloat
        let rotation: Double
        
        enum TaskType: Equatable {
            case multiTap(text: String, required: Int, color: Color)
            case slider(text: String, target: Double, color: Color)
            case stroop(prompt: String, validWord: String, options: [StroopOption])
            case logicToggle(text: String, requiredState: Bool, color: Color)
        }
        
        struct StroopOption: Equatable, Hashable {
            let word: String
            let colorIndex: Int
        }
    }
    
    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .trailing) {
                // Background
                Color.white.opacity(0.02).ignoresSafeArea()
                
                // Active Tasks Canvas
                ZStack {
                    ForEach(tasks) { task in
                        CognitiveTaskView(task: task) {
                            completeTask(task)
                        }
                        .offset(x: task.xOffset, y: task.yOffset)
                        .rotationEffect(.degrees(task.rotation))
                        .transition(.scale(scale: 0.95).combined(with: .opacity))
                        // The zIndex ensures newer tasks appear *above* older ones
                        .zIndex(Double(task.id))
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .blur(radius: isReflecting ? 15 : 0)
                
                // Top-Right Task Counter
                VStack {
                    HStack {
                        Spacer()
                        Text("Task: \(tasks.count)")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .padding(.top, 24)
                            .padding(.trailing, 24)
                            .opacity(tasks.isEmpty || isReflecting ? 0 : 1)
                            .animation(.easeInOut(duration: 1.2), value: isReflecting)
                    }
                    Spacer()
                }
            }
        }
        .onReceive(timer) { _ in
            guard !isReflecting else { return }
            timeElapsed += 0.1
            
            // Progressive overload: demands arrive faster over time
            let currentSpawnRate = max(1.2, 3.2 - (timeElapsed / 20.0))
            
            if timeElapsed - lastSpawnTime >= currentSpawnRate {
                addTask()
                lastSpawnTime = timeElapsed
                
                // Overlap: Secondary prompt appears before first resolves
                if timeElapsed > 6.0 && Double.random(in: 0...1) > 0.6 {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                        if !isReflecting { addTask() }
                    }
                }
            }
        }
        .onAppear {
            addTask()
        }
    }
    
    private func addTask() {
        taskCounter += 1
        
        // Ensure new tasks overlap but drift across the view area gradually
        let spreadX = min(220.0, 60.0 + (timeElapsed * 2.5))
        let spreadY = min(300.0, 80.0 + (timeElapsed * 3.0))
        
        let xOffset = CGFloat.random(in: -spreadX...spreadX)
        let yOffset = CGFloat.random(in: -spreadY...spreadY)
        let rotation = Double.random(in: -5...5)
        
        let type = generateRandomTaskType()
        
        let newTask = CognitiveTask(
            id: taskCounter,
            type: type,
            xOffset: xOffset,
            yOffset: yOffset,
            rotation: rotation
        )
        
        withAnimation(.easeInOut(duration: 1.2)) {
            tasks.append(newTask)
        }
    }
    
    private func completeTask(_ task: CognitiveTask) {
        guard let index = tasks.firstIndex(where: { $0.id == task.id }) else { return }
        
        // Mark as completing to trigger internal animations if needed, though mostly
        // we'll just remove it with a transition.
        withAnimation(.easeInOut(duration: 0.5)) {
            tasks[index].isCompleting = true
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            withAnimation(.easeInOut(duration: 1.0)) {
                tasks.removeAll(where: { $0.id == task.id })
            }
        }
    }
    
    private func generateRandomTaskType() -> CognitiveTask.TaskType {
        let colors: [Color] = [.blue, .purple, .orange, .teal, .indigo, .pink]
        let color = colors.randomElement() ?? .blue
        
        let rand = Int.random(in: 0...3)
        switch rand {
        case 0:
            let prompts = ["Confirm Data", "Reject Input", "System Check", "Verify Status"]
            let required = Int.random(in: 2...4)
            return .multiTap(text: prompts.randomElement()!, required: required, color: color)
        case 1:
            return .slider(text: "Calibrate frequency", target: Double.random(in: 0.2...0.8), color: color)
        case 2:
            let requiredState = Bool.random()
            let text = requiredState ? "Ensure process is ACTIVE" : "Ensure process is HALTED"
            return .logicToggle(text: text, requiredState: requiredState, color: color)
        default:
            let words = ["RED", "BLUE", "GREEN", "YELLOW"]
            let validWord = words.randomElement()!
            
            var options: [CognitiveTask.StroopOption] = []
            let availableWords = words.shuffled()
            let availableColorIndices = [0, 1, 2, 3].shuffled()
            
            for i in 0..<3 {
                options.append(CognitiveTask.StroopOption(word: availableWords[i], colorIndex: availableColorIndices[i]))
            }
            
            if !options.contains(where: { $0.word == validWord }) {
                options[0] = CognitiveTask.StroopOption(word: validWord, colorIndex: availableColorIndices[0])
            }
            options.shuffle()
            
            return .stroop(prompt: "Select word: \(validWord)", validWord: validWord, options: options)
        }
    }
}

// Separate view for the individual task cards to keep the main file clean
struct CognitiveTaskView: View {
    let task: CognitiveLoadExperience.CognitiveTask
    let onComplete: () -> Void
    
    // Local state for interactive tasks
    @State private var currentTaps: Int = 0
    @State private var sliderValue: Double = 0.0
    @State private var toggleState: Bool = false
    @State private var isError: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            // Task Header
            HStack(spacing: 8) {
                Circle()
                    .fill(taskColor)
                    .frame(width: 8, height: 8)
                
                Text(taskTitle)
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(.secondary)
                
                Spacer()
                
                if case let .multiTap(_, req, _) = task.type {
                    Text("\(currentTaps)/\(req)")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                        .animation(.none, value: currentTaps)
                }
            }
            
            // Task Content Interaction
            Group {
                switch task.type {
                case .multiTap(let text, let required, let color):
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            currentTaps += 1
                        }
                        if currentTaps >= required {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                                onComplete()
                            }
                        }
                    }) {
                        Text(text)
                            .font(.subheadline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .background(color)
                            .cornerRadius(8)
                    }
                    
                case .slider(let text, let target, let color):
                    VStack(alignment: .leading, spacing: 6) {
                        Text("\(text) (Target: \(Int(target * 100))%)")
                            .font(.caption2)
                            .foregroundColor(.primary.opacity(0.8))
                        
                        Slider(value: Binding(
                            get: { sliderValue },
                            set: { val in
                                sliderValue = val
                                if abs(val - target) < 0.04 {
                                    onComplete()
                                }
                            }
                        ), in: 0...1)
                        .tint(color)
                    }
                    
                case .logicToggle(let text, let required, let color):
                    VStack(alignment: .leading, spacing: 8) {
                        Text(text)
                            .font(.caption2)
                            .foregroundColor(.primary.opacity(0.8))
                            .fixedSize(horizontal: false, vertical: true)
                        
                        Toggle(isOn: Binding(
                            get: { toggleState },
                            set: { val in
                                withAnimation(.easeInOut(duration: 0.4)) {
                                    toggleState = val
                                }
                                if val == required {
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                                        if toggleState == required {
                                            onComplete()
                                        }
                                    }
                                }
                            }
                        )) {
                            Text(toggleState ? "ACTIVE" : "HALTED")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .animation(.none, value: toggleState)
                        }
                        .tint(color)
                    }
                    .onAppear {
                        toggleState = !required
                    }
                    
                case .stroop(let prompt, let validWord, let options):
                    VStack(alignment: .leading, spacing: 10) {
                        Text(prompt)
                            .font(.caption2)
                            .fontWeight(.semibold)
                        
                        HStack(spacing: 8) {
                            ForEach(options, id: \.word) { option in
                                Button(action: {
                                    if option.word == validWord {
                                        onComplete()
                                    } else {
                                        showError()
                                    }
                                }) {
                                    Text(option.word)
                                        .font(.caption)
                                        .fontWeight(.bold)
                                        .padding(.horizontal, 6)
                                        .padding(.vertical, 10)
                                        .frame(maxWidth: .infinity)
                                        .background(Color.primary.opacity(0.06))
                                        .foregroundColor(getColor(from: option.colorIndex))
                                        .cornerRadius(6)
                                }
                            }
                        }
                    }
                }
            }
        }
        .padding(18)
        .frame(width: 270)
        .background(.regularMaterial)
        .cornerRadius(18)
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(isError ? Color.red.opacity(0.6) : Color.clear, lineWidth: 2)
        )
        .shadow(color: Color.black.opacity(0.08), radius: 12, y: 6)
        .opacity(task.isCompleting ? 0 : 1)
        .scaleEffect(task.isCompleting ? 0.9 : 1.0)
        .offset(x: isError ? 6 : 0)
        .animation(.spring(response: 0.3, dampingFraction: 0.2), value: isError)
    }
    
    private func showError() {
        isError = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            isError = false
        }
    }
    
    private func getColor(from index: Int) -> Color {
        switch index {
        case 0: return .red
        case 1: return .blue
        case 2: return .indigo
        case 3: return .orange
        default: return .primary
        }
    }
    
    private var taskColor: Color {
        switch task.type {
        case .multiTap(_, _, let c), .slider(_, _, let c), .logicToggle(_, _, let c):
            return c
        case .stroop:
            return .purple
        }
    }
    
    private var taskTitle: String {
        switch task.type {
        case .multiTap: return "Action Sequence"
        case .slider: return "Fine Calibration"
        case .logicToggle: return "Logical Verification"
        case .stroop: return "Semantic Conflict"
        }
    }
}

struct InteractionPrecisionExperience: View {
    let isReflecting: Bool
    
    @State private var position: CGPoint = .zero
    @State private var visualOffset: CGSize = .zero
    @State private var driftOffset: CGSize = .zero
    @State private var attempts = 0
    @State private var hits = 0
    @State private var time: Double = 0
    @State private var targetScale: CGFloat = 1.0
    @State private var tapFeedback: Color = .clear
    @State private var isGlinting = false
    @State private var showShatter = false
    @State private var isJammed = false
    
    let timer = Timer.publish(every: 0.05, on: .main, in: .common).autoconnect()
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                // Background Depth
                Color.black.opacity(0.8).ignoresSafeArea()
                
                // Top-Right Stats
                VStack {
                    HStack {
                        Spacer()
                        VStack(alignment: .trailing, spacing: 4) {
                            Text("PRECISION HITS: \(hits)")
                                .font(.system(.subheadline, design: .monospaced))
                                .foregroundColor(.accentColor)
                            Text("TOTAL ATTEMPTS: \(attempts)")
                                .font(.system(.caption, design: .monospaced))
                                .foregroundColor(.secondary)
                        }
                        .padding(24)
                        .opacity(isReflecting ? 0 : 1)
                    }
                    Spacer()
                }
                
                // The Target Interaction Zone
                ZStack {
                    if showShatter {
                        Circle()
                            .stroke(Color.red.opacity(0.8), lineWidth: 2)
                            .scaleEffect(2.0)
                            .opacity(0)
                    }
                    
                    // Visual Ghost (The shimmer the user sees)
                    TargetCircle(scale: targetScale, glint: isGlinting, stability: hits, isJammed: isJammed)
                        .offset(visualOffset)
                        .offset(driftOffset)
                        .opacity(0.6)
                        .blur(radius: isJammed ? 4 : 2)
                    
                    // Actual Hitbox
                    Button(action: { }) {
                        Circle()
                            .fill(Color.white.opacity(0.01))
                            .frame(width: 80 * targetScale, height: 80 * targetScale)
                    }
                    .simultaneousGesture(
                        DragGesture(minimumDistance: 0)
                            .onEnded { val in
                                evaluateHit(at: val.location)
                            }
                    )
                }
                .position(position)
                
                // Tremor Simulation Overlay
                if !isReflecting {
                    Color.white.opacity(0.01)
                        .offset(x: CGFloat(sin(time * 80) * 0.5), y: CGFloat(cos(time * 75) * 0.5))
                        .allowsHitTesting(false)
                }
            }
            .onAppear {
                position = CGPoint(x: geo.size.width / 2, y: geo.size.height / 2)
            }
            .onReceive(timer) { _ in
                guard !isReflecting else { return }
                time += 0.05
                
                // 1. Visual Ghosting
                withAnimation(.linear(duration: 0.05)) {
                    visualOffset = CGSize(
                        width: sin(time * 4) * 15,
                        height: cos(time * 3.5) * 15
                    )
                }
                
                // 2. Magnetic Drift: Continuous unpredictable movement
                withAnimation(.linear(duration: 0.05)) {
                    driftOffset.width += CGFloat(sin(time * 1.2) * 2.0)
                    driftOffset.height += CGFloat(cos(time * 1.5) * 2.0)
                }
                
                // 4. Glint Flickering
                if Int(time * 20) % 2 == 0 {
                    isGlinting.toggle()
                }
                
                // Every few seconds, check for a "Jam"
                if Int(time * 10) % 60 == 0 && !isJammed {
                    if Double.random(in: 0...1) > 0.85 {
                        withAnimation { isJammed = true }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                            withAnimation { isJammed = false }
                        }
                    }
                }
            }
        }
        .blur(radius: isReflecting ? 15 : 0)
    }
    
    private func evaluateHit(at point: CGPoint) {
        guard !isReflecting else { return }
        attempts += 1
        
        let center = position
        let distance = sqrt(pow(point.x - center.x, 2) + pow(point.y - center.y, 2))
        let radius = 40 * targetScale
        
        // Handle Jamming (Click Friction)
        if isJammed {
            withAnimation(.easeInOut(duration: 0.1)) { isJammed = false } // Tap clears jam but doesn't hit
            return
        }
        
        if distance < radius * 0.3 {
            hits += 1
            withAnimation(.spring(response: 0.3, dampingFraction: 0.5)) {
                targetScale = max(0.4, 1.0 - CGFloat(hits) * 0.06)
                position = randomPosition()
                driftOffset = .zero // Reset drift on hit
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                tapFeedback = .indigo
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    tapFeedback = .clear
                }
            }
        } else if distance < radius {
            triggerShatter()
        }
    }
    
    private func triggerShatter() {
        withAnimation { showShatter = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
            showShatter = false
            withAnimation {
                hits = max(0, hits - 1)
                targetScale = 1.0
            }
        }
    }
    
    private func randomPosition() -> CGPoint {
        // Keep within safe bounds
        CGPoint(
            x: CGFloat.random(in: 100...300), 
            y: CGFloat.random(in: 200...500)
        )
    }
}

private struct TargetCircle: View {
    let scale: CGFloat
    let glint: Bool
    let stability: Int
    let isJammed: Bool
    
    var body: some View {
        ZStack {
            // Outer Ring
            Circle()
                .stroke(isJammed ? Color.red.opacity(0.8) : Color.white.opacity(0.2), lineWidth: 1)
                .frame(width: 80 * scale, height: 80 * scale)
            
            // Inner Precision Core
            Circle()
                .fill(
                    RadialGradient(
                        colors: [isJammed ? Color.red : Color.orange, Color.red.opacity(0.8)],
                        center: .center,
                        startRadius: 0,
                        endRadius: 20 * scale
                    )
                )
                .frame(width: 24 * scale, height: 24 * scale)
                .shadow(color: .red.opacity(glint ? 0.8 : 0.4), radius: glint ? 12 : 6)
                .scaleEffect(isJammed ? 1.2 : 1.0)
                .animation(.interpolatingSpring(stiffness: 120, damping: 10), value: isJammed)
            
            // Stability HUD
            if scale < 0.9 {
                Text(String(repeating: "|", count: min(stability, 15)))
                    .font(.system(size: 8, weight: .black, design: .monospaced))
                    .foregroundColor(isJammed ? .red : .white.opacity(0.3))
                    .offset(y: 45 * scale)
            }
        }
    }
}
