import SwiftUI

class OnboardingViewModel: ObservableObject {
    private let store: AppStore
    
    init(store: AppStore) {
        self.store = store
    }
    
    func completeOnboarding() {
        withAnimation(.easeInOut(duration: 1.0)) {
            store.flow = .hub
        }
    }
}
