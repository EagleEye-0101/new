import SwiftUI

class SynthesisViewModel: ObservableObject {
    private let store: AppStore
    
    init(store: AppStore) {
        self.store = store
    }
    
    func restartApp() {
        withAnimation(.easeInOut(duration: 1.0)) {
            store.completedExperiences = []
            store.flow = .onboarding
            store.hubState = .idle
        }
    }
}
