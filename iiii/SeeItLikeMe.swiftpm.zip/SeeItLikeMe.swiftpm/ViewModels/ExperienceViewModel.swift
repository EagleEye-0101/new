import SwiftUI

class ExperienceViewModel: ObservableObject {
    private let store: AppStore
    
    init(store: AppStore) {
        self.store = store
    }
    
    var hubState: HubState { store.hubState }
    
    func startActiveExperience(_ kind: ExperienceKind) {
        store.startActiveExperience(kind)
    }
    
    func triggerReflection(_ kind: ExperienceKind) {
        store.triggerReflection(kind)
    }
    
    func finishJourney(_ kind: ExperienceKind) {
        store.finishJourney(kind)
    }
}
